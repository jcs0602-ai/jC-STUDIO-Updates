import os, sys, json, time, random, shutil, subprocess, threading, urllib.request, urllib.error, webbrowser, tempfile, uuid, re, hashlib, zipfile, py_compile
from datetime import datetime
from pathlib import Path

# --- jC-STUDIO portable installation root ---
# Installer/launcher sets JC_STUDIO_HOME. If absent, App's parent is used.
JC_HOME = Path(os.environ.get("JC_STUDIO_HOME", str(Path(__file__).resolve().parent.parent))).resolve()
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP='jC-STUDIO V3.1 STABLE · Portable Fix 1'
BASE=Path(__file__).resolve().parent
HOME=JC_HOME
SONGS=HOME/"Songs"
MODELS=Path(os.environ.get('JC_STUDIO_MODELS_HOME', r'D:\jC-STUDIO\Engine\py-runtime\models'))
ENGINE=Path(os.environ.get('JC_STUDIO_ENGINE_HOME', r'D:\jC-STUDIO\Engine'))
LOGS=HOME/"Logs"
SETTINGS=HOME/"Settings"
RUNTIME_CFG=SETTINGS/"runtime.json"
for p in (HOME,SONGS,MODELS,ENGINE,LOGS,SETTINGS): p.mkdir(parents=True,exist_ok=True)
MODEL_URLS={
 'YuE2-3B-Q8_0.gguf':'https://huggingface.co/Serveurperso/YuE2-GGUF/resolve/main/YuE2-3B-Q8_0.gguf?download=true',
 'YuE2-Vae-F32.gguf':'https://huggingface.co/Serveurperso/YuE2-GGUF/resolve/main/YuE2-Vae-F32.gguf?download=true'
}
DEFAULT_STYLE='Korean CCM, mature warm female alto, low-mid register, clear Korean diction, warm acoustic piano, fingerpicked acoustic guitar, cello, upright bass, light brushed percussion, gentle hopeful worship mood, no belting, no key change, no EDM, no rock drums, intimate dry vocal'

GENRE_PRESETS={
 'Acoustic Cinematic CCM':'acoustic cinematic Korean CCM, intimate verses, gently expansive worship texture',
 '어쿠스틱 CCM':'intimate acoustic Korean CCM worship',
 'CCM 발라드':'warm Korean CCM ballad',
 '모던 워십':'modern Korean worship, spacious contemporary CCM',
 '컨템포러리 CCM':'contemporary Korean CCM, polished organic worship',
 '시니어 CCM':'senior-friendly Korean CCM, warm unhurried worship ballad',
 '포크 워십':'warm Korean folk worship',
 '어쿠스틱 포크 CCM':'organic acoustic Korean folk CCM',
 '재즈 CCM':'warm Korean jazz CCM, tasteful gospel-jazz harmony, relaxed worship feel',
 '재즈 발라드 CCM':'gentle Korean jazz ballad CCM, intimate worship mood',
 '스윙 워십':'light Korean swing worship, restrained swing groove, warm gospel-jazz color',
 '감성 트로트 CCM':'warm sentimental Korean trot CCM, restrained trot phrasing, devotional and sincere',
 '어쿠스틱 트로트 CCM':'acoustic Korean trot CCM, gentle trot pulse, organic worship arrangement',
 '세미 트로트 CCM':'soft semi-trot Korean CCM, moderate rhythmic lift, warm devotional character',
 'CCM Pop':'Korean CCM pop, melodic contemporary worship pop',
 'Acoustic CCM Pop':'acoustic Korean CCM pop, organic contemporary worship',
 'Soft Pop Worship':'soft Korean pop worship, gentle contemporary CCM',
 '찬송가풍':'simple hymn-inspired Korean worship',
 'Gospel Hymn':'Korean gospel hymn, warm traditional harmony, restrained gospel character',
 '오르간 워십':'reverent Korean organ worship, hymn-like sacred atmosphere',
 'Cinematic Worship':'cinematic Korean worship, restrained orchestral warmth, devotional atmosphere'
}
INSTRUMENT_PRESETS={
 '피아노 + 첼로':'felt piano, solo cello, warm upright bass, very light brushed percussion',
 '핑거 기타 + 피아노':'fingerpicked acoustic guitar, felt piano, warm upright bass, light brushes',
 '하프 + 오보에 + 첼로':'gentle harp, warm oboe, solo cello, soft restrained strings',
 '피아노 + 클라리넷 + 첼로':'felt piano, warm clarinet, solo cello, subtle harp, restrained strings',
 '피아노 + 비올라 + 첼로':'warm piano, viola, solo cello, soft restrained strings',
 '알토 색소폰 포함':'warm piano, fingerpicked acoustic guitar, low-register alto saxophone responses, upright bass, light brushes',
 '직접 입력':'',
}
EXCLUDE_DEFAULT='no high belting, no falsetto, no key change, no dramatic modulation, no EDM, no rock drums, no brass section, no hard autotune, no piercing synths, no theatrical choir, no gender switching'

VOCAL_TONE_PRESETS={
 '기본 · 자연스러움':'natural balanced vocal tone, clean unforced resonance',
 '따뜻하고 풍성함':'warm rich full-bodied vocal tone, smooth low-mid resonance, natural chest resonance, rich natural harmonics',
 '깊고 중후함':'deep resonant vocal tone, rich low-mid harmonics, grounded chest resonance, mature rounded timbre',
 '부드럽고 풍성함':'smooth rounded full-bodied vocal tone, soft rich midrange, gentle natural resonance',
 '맑고 풍성함':'clear open vocal tone, rich natural harmonics, balanced full-bodied resonance, clean presence',
 '감성적':'emotionally expressive warm resonant vocal tone, nuanced natural phrasing, controlled vibrato, sincere delivery',
 '가까운 보컬':'intimate close-miked vocal, warm presence, detailed natural breath, rich low-mid body, restrained room ambience'
}
VOCAL_RICHNESS={
 1:'lean and restrained vocal body, very natural dynamics, minimal coloration',
 2:'natural vocal body, balanced resonance, subtle warmth',
 3:'fuller vocal body, warm low-mid presence, richer natural harmonics',
 4:'rich full-bodied vocal, strong but natural chest resonance, lush low-mid harmonics',
 5:'deeply rich full-bodied vocal, dense natural harmonics, powerful low-mid resonance without belting'
}

class App(tk.Tk):
 def __init__(self):
  super().__init__(); self.title('jC-STUDIO V3.2.1 DEV · UI Refresh')
  sw,sh=self.winfo_screenwidth(),self.winfo_screenheight()
  # Start at an optimized normal-window size: large enough to show the full menu,
  # but not maximized. The normal Windows maximize button remains available.
  ww=min(1420,max(1080,sw-70))
  wh=min(960,max(760,sh-70))
  ww=min(ww,sw-30); wh=min(wh,sh-55)
  x=max(0,(sw-ww)//2); y=max(0,(sh-wh)//2-5)
  self.geometry(f'{ww}x{wh}+{x}+{y}')
  self.minsize(900,650)
  self.engine_proc=None; self.worker_proc=None; self.player_proc=None; self.player_audio=None; self.player_paused=False; self.player_position=0.0; self.player_started_at=None; self.player_duration=0.0; self.player_seeking=False; self.player_backend=None; self.player_base_position=0.0; self.engine_path=tk.StringVar(value=''); self.outdir=tk.StringVar(value=str(SONGS)); self.gen_started=None; self.gen_folder=None; st=ttk.Style(self)
  st.configure('TButton',font=('Malgun Gothic',10,'bold'))
  st.configure('TLabel',font=('Malgun Gothic',10,'bold'))
  st.configure('TCheckbutton',font=('Malgun Gothic',10,'bold'))
  st.configure('TRadiobutton',font=('Malgun Gothic',10,'bold'))
  st.configure('TNotebook.Tab',font=('Malgun Gothic',10,'bold'))
  st.configure('TLabelframe.Label',font=('Malgun Gothic',10,'bold'))
  st.configure('TMenubutton',font=('Malgun Gothic',10,'bold'))

  try:
   st.theme_use('clam')
   BG='#171B22'; PANEL='#202630'; PANEL2='#272E39'; TEXT='#E8EDF4'; MUTED='#AAB4C3'
   BLUE='#4EA1FF'; GREEN='#61C98D'; GOLD='#E6B85C'; PURPLE='#B28DFF'
   self.configure(bg=BG)
   st.configure('.',background=BG,foreground=TEXT,fieldbackground=PANEL2)
   st.configure('TFrame',background=BG)
   st.configure('TLabel',background=BG,foreground=TEXT)
   st.configure('Treeview',
                background='#F7F9FC',
                fieldbackground='#F7F9FC',
                foreground='#18202A',
                rowheight=28,
                borderwidth=0)
   st.configure('Treeview.Heading',
                background='#2B3440',
                foreground='#FFFFFF',
                font=('Malgun Gothic',10,'bold'),
                relief='flat')
   st.map('Treeview',
          background=[('selected','#2F78B7')],
          foreground=[('selected','#FFFFFF')])
   st.map('Treeview.Heading',
          background=[('active','#3A4655')])
   st.configure('TNotebook',background=BG,borderwidth=0)
   st.configure('TNotebook.Tab',background=PANEL,foreground=MUTED,padding=(14,7),font=('Malgun Gothic',10,'bold'))
   st.map('TNotebook.Tab',background=[('selected',PANEL2)],foreground=[('selected',BLUE)])
   st.configure('TButton',background=PANEL2,foreground=TEXT,padding=(9,6),borderwidth=1)
   st.configure('JC.Primary.TButton',background='#2F78B7',foreground='#FFFFFF',padding=(10,7),borderwidth=1,font=('Malgun Gothic',10,'bold'))
   st.map('JC.Primary.TButton',
          background=[('active','#4EA1FF'),('pressed','#245E91'),('disabled','#4A5360')],
          foreground=[('disabled','#C1C7D0')])
   st.map('TButton',background=[('active','#343D4B')],foreground=[('active','#FFFFFF')])
   st.configure('TEntry',fieldbackground=PANEL2,foreground=TEXT)
   st.configure('TCombobox',fieldbackground='#F7F9FC',background='#F7F9FC',foreground='#18202A',arrowcolor='#18202A')
   st.map('TCombobox',
          fieldbackground=[('readonly','#F7F9FC'),('disabled','#DDE3EA')],
          foreground=[('readonly','#18202A'),('disabled','#6D7784')],
          selectbackground=[('readonly','#DCEBFA')],
          selectforeground=[('readonly','#18202A')])
   self.option_add('*TCombobox*Listbox.background','#F7F9FC')
   self.option_add('*TCombobox*Listbox.foreground','#18202A')
   self.option_add('*TCombobox*Listbox.selectBackground','#2F78B7')
   self.option_add('*TCombobox*Listbox.selectForeground','#FFFFFF')
   st.configure('TLabelframe',background=PANEL,borderwidth=1,relief='solid')
   st.configure('TLabelframe.Label',background=PANEL,foreground=TEXT,font=('Malgun Gothic',10,'bold'))
   st.configure('JC.Settings.TLabelframe',background=PANEL)
   st.configure('JC.Settings.TLabelframe.Label',background=PANEL,foreground=BLUE,font=('Malgun Gothic',10,'bold'))
   st.configure('JC.Vocal.TLabelframe',background=PANEL)
   st.configure('JC.Vocal.TLabelframe.Label',background=PANEL,foreground=GREEN,font=('Malgun Gothic',10,'bold'))
   st.configure('JC.Preset.TLabelframe',background=PANEL)
   st.configure('JC.Preset.TLabelframe.Label',background=PANEL,foreground=GOLD,font=('Malgun Gothic',10,'bold'))
   st.configure('JC.Generate.TLabelframe',background=PANEL)
   st.configure('JC.Generate.TLabelframe.Label',background=PANEL,foreground=PURPLE,font=('Malgun Gothic',10,'bold'))
   st.configure('Vertical.TScrollbar',
                background='#6E7C90',
                troughcolor='#10141A',
                arrowcolor='#FFFFFF',
                bordercolor='#10141A',
                lightcolor='#6E7C90',
                darkcolor='#6E7C90',
                width=18)
   st.map('Vertical.TScrollbar',
          background=[('active','#4EA1FF'),('pressed','#2F78B7')],
          arrowcolor=[('active','#FFFFFF'),('pressed','#FFFFFF')])
   st.configure('Horizontal.TScrollbar',
                background='#6E7C90',
                troughcolor='#10141A',
                arrowcolor='#FFFFFF',
                bordercolor='#10141A',
                lightcolor='#6E7C90',
                darkcolor='#6E7C90',
                width=18)
   st.map('Horizontal.TScrollbar',
          background=[('active','#4EA1FF'),('pressed','#2F78B7')],
          arrowcolor=[('active','#FFFFFF'),('pressed','#FFFFFF')])
  except Exception:pass
  self._build(); self.protocol('WM_DELETE_WINDOW',self.on_close); self.after(250,self.diagnose)
 def _build(self):
  root=ttk.Frame(self,padding=12); root.pack(fill='both',expand=True)
  header=ttk.Frame(root); header.pack(fill='x',anchor='w')
  try:
   logo_path=Path(__file__).resolve().parent/'Assets'/'jc_logo.png'
   self.header_logo=tk.PhotoImage(file=str(logo_path))
   ttk.Label(header,image=self.header_logo).pack(side='left',padx=(0,10),pady=(0,2))
  except Exception:
   self.header_logo=None
  titlebox=ttk.Frame(header); titlebox.pack(side='left',anchor='w')
  ttk.Label(titlebox,text='jC-STUDIO',font=('Malgun Gothic',25,'bold')).pack(anchor='w')
  self.nb=ttk.Notebook(root); self.nb.pack(fill='both',expand=True)
  self.music_tab=ttk.Frame(self.nb); self.library=ttk.Frame(self.nb,padding=10); self.score=ttk.Frame(self.nb,padding=10); self.subtitles=ttk.Frame(self.nb,padding=10); self.advanced=ttk.Frame(self.nb,padding=10); self.system=ttk.Frame(self.nb,padding=10)
  self.nb.add(self.music_tab,text='음악 제작'); self.nb.add(self.library,text='생성곡 라이브러리'); self.nb.add(self.score,text='악보'); self.nb.add(self.subtitles,text='자동 자막'); self.nb.add(self.advanced,text='고급 설정'); self.nb.add(self.system,text='시스템')
  self.music_canvas=tk.Canvas(self.music_tab,highlightthickness=0,bg='#171B22')
  self.music_scroll=ttk.Scrollbar(self.music_tab,orient='vertical',command=self.music_canvas.yview)
  self.music_canvas.configure(yscrollcommand=self.music_scroll.set)
  self.music_scroll.pack(side='right',fill='y'); self.music_canvas.pack(side='left',fill='both',expand=True)
  self.music=ttk.Frame(self.music_canvas,padding=6)
  self._music_window=self.music_canvas.create_window((0,0),window=self.music,anchor='nw')
  self.music.bind('<Configure>',lambda e:self.music_canvas.configure(scrollregion=self.music_canvas.bbox('all')))
  self.music_canvas.bind('<Configure>',lambda e:self.music_canvas.itemconfigure(self._music_window,width=e.width))
  self.music_canvas.bind('<MouseWheel>',lambda e:self.music_canvas.yview_scroll(int(-1*(e.delta/120)),'units'))
  self._music(); self._library(); self._score(); self._subtitles(); self._advanced(); self._system()
 def _apply_responsive_settings_layout(self):
  if not hasattr(self,'_setting_widgets'):return
  w=self.winfo_width()
  pairs=2 if w<900 else (3 if w<1200 else len(self._setting_widgets))
  for lab,ctl in self._setting_widgets:
   lab.grid_forget();ctl.grid_forget()
  for i,(lab,ctl) in enumerate(self._setting_widgets):
   row=i//pairs; col=(i%pairs)*2
   lab.grid(row=row,column=col,sticky='w',padx=(0,4),pady=2)
   ctl.grid(row=row,column=col+1,sticky='ew',padx=(0,10),pady=2)
   top=getattr(lab,'master',None)
   if top: top.columnconfigure(col+1,weight=1)

 def _responsive_settings_layout(self,event=None):
  self.after_idle(self._apply_responsive_settings_layout)

 def _apply_responsive_music_layout(self):
  if not hasattr(self,'_music_mid'): return
  w=self._music_mid.winfo_width()
  if w<=1: w=self.winfo_width()
  mode='narrow' if w<980 else 'wide'
  if mode==self._music_layout_mode:return
  h=self.winfo_height()
  compact_h = h < 820
  if hasattr(self,'lyrics'):
   try:self.lyrics.configure(height=(7 if compact_h else (9 if mode=='narrow' else 11)))
   except Exception:pass
  if hasattr(self,'style'):
   try:self.style.configure(height=(3 if compact_h else 4))
   except Exception:pass
  self._music_layout_mode=mode
  l,r=self._music_left,self._music_right
  l.grid_forget(); r.grid_forget()
  if mode=='wide':
   l.grid(row=0,column=0,sticky='nsew',padx=(0,8))
   r.grid(row=0,column=1,sticky='nsew',padx=(8,0))
   self._music_mid.columnconfigure(0,weight=3); self._music_mid.columnconfigure(1,weight=2)
  else:
   l.grid(row=0,column=0,sticky='nsew')
   r.grid(row=1,column=0,sticky='nsew',pady=(10,0))
   self._music_mid.columnconfigure(0,weight=1); self._music_mid.columnconfigure(1,weight=0)
  self._music_mid.rowconfigure(0,weight=1)

 def _responsive_music_layout(self,event=None):
  # Re-evaluate both width and height so input areas shrink before scrolling is needed.
  self._music_layout_mode=None
  self.after_idle(self._apply_responsive_music_layout)

 def _music(self):
  top=ttk.LabelFrame(self.music,text='곡 설정',style='JC.Settings.TLabelframe',padding=10); top.pack(fill='x')
  self.titlev=tk.StringVar(value='새 찬양'); self.bpm=tk.IntVar(value=70); self.key=tk.StringVar(value='G Major'); self.voice=tk.StringVar(value='여성 · 따뜻한 알토'); self.vocal_tone=tk.StringVar(value='기본 · 자연스러움'); self.vocal_richness=tk.IntVar(value=2); self.length=tk.StringVar(value='자유 길이'); self.seed=tk.StringVar(value='랜덤'); self.genre=tk.StringVar(value='Acoustic Cinematic CCM'); self.instrument=tk.StringVar(value='자동 추천'); self.auto_exclude=tk.BooleanVar(value=True)
  self.prompt_mode=tk.StringVar(value='자동 생성'); self.manual_voice_lock=tk.BooleanVar(value=False); self.manual_exclude=tk.BooleanVar(value=False); self.song_count=tk.IntVar(value=1)
  items=[('제목',self.titlev,None),('BPM',self.bpm,None),('조성',self.key,['G Major','D Major','E Major','E♭ Major','C Major','A Major']),('보컬',self.voice,[
'여성 · 일반 내추럴','여성 · 따뜻한 알토','여성 · 깊은 알토','여성 · 부드러운 메조','여성 · 밝은 메조','여성 · 맑은 소프라노','여성 · 허스키','여성 · 시니어 알토',
'남성 · 일반 내추럴','남성 · 따뜻한 바리톤','남성 · 깊은 바리톤','남성 · 부드러운 테너','남성 · 밝은 테너','남성 · 허스키','남성 · 시니어 바리톤',
'듀엣 · 남성 바리톤 + 여성 알토','듀엣 · 남성 테너 + 여성 메조','듀엣 · 시니어 남녀','듀엣 · 남성 2인','듀엣 · 여성 2인','듀엣 · 저음 남녀',
'악기 연주']),('목표 길이',self.length,['30초 엔진 테스트','약 1분','약 2분','2분 40초','약 3분','약 3분 30초','약 4분','약 4분 30초','약 5분','약 5분 30초','약 6분','자유 길이'])]
  self._setting_widgets=[]
  for i,(lab,var,vals) in enumerate(items):
   labw=ttk.Label(top,text=lab); w=ttk.Combobox(top,textvariable=var,values=vals,state='readonly') if vals else ttk.Entry(top,textvariable=var)
   self._setting_widgets.append((labw,w))
  top.bind('<Configure>',self._responsive_settings_layout)
  self.after(120,self._apply_responsive_settings_layout)
  tonebox=ttk.LabelFrame(self.music,text='보컬 음색 · 풍성함',padding=8); tonebox.pack(fill='x',pady=(6,4))
  rt=ttk.Frame(tonebox); rt.pack(fill='x')
  ttk.Label(rt,text='음색',width=8).pack(side='left')
  cb=ttk.Combobox(rt,textvariable=self.vocal_tone,state='readonly',values=list(VOCAL_TONE_PRESETS.keys()),width=24); cb.pack(side='left',fill='x',expand=True)
  rr=ttk.Frame(tonebox); rr.pack(fill='x',pady=(6,0))
  ttk.Label(rr,text='풍성함',width=8).pack(side='left')
  ttk.Scale(rr,from_=1,to=5,variable=self.vocal_richness,orient='horizontal',length=180,command=lambda _=None:self._richness_changed()).pack(side='left',fill='x',expand=True)
  self.vocal_richness_label=tk.StringVar(value='2 · 자연'); ttk.Label(rr,textvariable=self.vocal_richness_label,width=12).pack(side='left',padx=(8,0))
  ttk.Label(tonebox,text='권장: 일반 내추럴 + 따뜻하고 풍성함 + 3. 기본값 2는 기존 자연스러운 보컬을 유지합니다.',wraplength=350,justify='left').pack(anchor='w',pady=(5,0))
  self.vocal_tone.trace_add('write',lambda *_: self.refresh_final_prompt())
  preset=ttk.LabelFrame(self.music,text='CCM 프리셋',padding=8); preset.pack(fill='x',pady=(8,0))
  ttk.Label(preset,text='장르').pack(side='left'); ttk.Combobox(preset,textvariable=self.genre,values=list(GENRE_PRESETS),state='readonly',width=24).pack(side='left',padx=(5,14))
  ttk.Label(preset,text='악기').pack(side='left'); ttk.Combobox(preset,textvariable=self.instrument,values=list(INSTRUMENT_PRESETS),state='readonly',width=26).pack(side='left',padx=(5,14))
  ttk.Checkbutton(preset,text='제외 스타일 자동 적용',variable=self.auto_exclude,command=self.refresh_final_prompt).pack(side='left')
  mid=ttk.Frame(self.music); mid.pack(fill='both',expand=True,pady=(5,3))
  l=ttk.Frame(mid); r=ttk.Frame(mid)
  self._music_mid=mid; self._music_left=l; self._music_right=r; self._music_layout_mode=None
  mid.bind('<Configure>',self._responsive_music_layout)
  self.after(100,self._apply_responsive_music_layout)
  ttk.Label(l,text='가사').pack(anchor='w'); self.lyrics=tk.Text(l,wrap='word',font=('Malgun Gothic',11)); self.lyrics.pack(fill='both',expand=True,pady=4); self.lyrics.configure(bg='#11151B',fg='#E8EDF4',insertbackground='#E8EDF4',selectbackground='#315A7D',relief='flat',highlightthickness=1,highlightbackground='#343D4B'); self.lyrics.insert('1.0','[Verse 1]\n\n[Chorus]\n\n[Verse 2]\n\n[Chorus]\n')
  promptbar=ttk.Frame(l); promptbar.pack(fill='x',pady=(5,2))
  ttk.Label(promptbar,text='YuE2 최종 스타일 프롬프트').pack(side='left')
  for label in ('자동 생성','자동 생성 후 편집','직접 붙여넣기'):
   ttk.Radiobutton(promptbar,text=label,value=label,variable=self.prompt_mode,command=self.on_prompt_mode_change).pack(side='left',padx=(10,0))
  self.style=tk.Text(l,height=4,wrap='word'); self.style.pack(fill='x',pady=4)
  manualbar=ttk.Frame(l); manualbar.pack(fill='x')
  ttk.Checkbutton(manualbar,text='Voice Lock 추가',variable=self.manual_voice_lock).pack(side='left')
  ttk.Checkbutton(manualbar,text='제외 스타일 추가',variable=self.manual_exclude).pack(side='left',padx=(10,0))
  ttk.Button(manualbar,text='선택 설정을 프롬프트에 추가',command=self.apply_manual_prompt_additions).pack(side='left',padx=(12,0))
  ttk.Label(manualbar,text='직접 붙여넣기/편집 모드에서만 사용').pack(side='left',padx=(10,0))
  for v in (self.bpm,self.key,self.voice,self.length,self.genre,self.instrument): v.trace_add('write',lambda *_: self.refresh_final_prompt())
  self.after(50,self.on_prompt_mode_change)
  box=ttk.LabelFrame(r,text='제작',padding=10); box.pack(fill='x')
  ttk.Label(box,text='저장 위치').pack(anchor='w'); ttk.Entry(box,textvariable=self.outdir).pack(fill='x'); ttk.Button(box,text='저장 폴더 선택',command=self.choose_out).pack(fill='x',pady=5)
  ttk.Label(box,text='Seed (랜덤 또는 고정 숫자)').pack(anchor='w',pady=(7,0)); ttk.Entry(box,textvariable=self.seed).pack(fill='x'); ttk.Button(box,text='Seed 고정값 만들기',command=lambda:self.seed.set(str(random.randrange(2**31)))).pack(fill='x',pady=3)
  countrow=ttk.Frame(box); countrow.pack(fill='x',pady=(9,2))
  ttk.Label(countrow,text='생성 곡수').pack(side='left')
  ttk.Combobox(countrow,textvariable=self.song_count,values=[1,2,3],state='readonly',width=6).pack(side='right')
  ttk.Label(box,text='2~3곡 선택 시 같은 설정으로 Seed를 달리해 순서대로 생성합니다.',wraplength=350,justify='left').pack(anchor='w',pady=(2,4))
  ttk.Label(box,text='보컬 프리셋은 YuE2 최종 Style Prompt에 자동 반영됩니다. 같은 프리셋도 Seed에 따라 음색이 조금 달라질 수 있습니다.',wraplength=350,justify='left').pack(anchor='w',pady=(0,4))
  self.make_btn=ttk.Button(box,text='음악 만들기',command=self.generate,state='normal',style='JC.Primary.TButton'); self.make_btn.pack(fill='x',pady=(8,3))
  self.music_status=tk.StringVar(value='시스템 탭에서 YuE2 엔진과 모델을 준비해 주세요.'); ttk.Label(box,textvariable=self.music_status,wraplength=360,justify='left').pack(anchor='w',pady=8)
  prog=ttk.LabelFrame(r,text='생성 진행',padding=10); prog.pack(fill='x',pady=(10,0))
  self.gen_percent=tk.DoubleVar(value=0); self.gen_stage=tk.StringVar(value='대기'); self.gen_time=tk.StringVar(value='경과 00:00'); self.gen_eta=tk.StringVar(value='예상 남은 시간 --:--')
  self.gen_bar=ttk.Progressbar(prog,maximum=100,variable=self.gen_percent,mode='determinate'); self.gen_bar.pack(fill='x',pady=(2,6))
  self.gen_percent_text=tk.StringVar(value='0%'); ttk.Label(prog,textvariable=self.gen_percent_text,font=('Malgun Gothic',16,'bold')).pack(anchor='center')
  ttk.Label(prog,textvariable=self.gen_stage).pack(anchor='w',pady=(4,0)); ttk.Label(prog,textvariable=self.gen_time).pack(anchor='w'); ttk.Label(prog,textvariable=self.gen_eta).pack(anchor='w')
  act=ttk.Frame(prog); act.pack(fill='x',pady=(8,0))
  self.play_btn=ttk.Button(act,text='완성곡 재생',command=self.play_result,state='disabled'); self.play_btn.pack(side='left',expand=True,fill='x',padx=(0,3))
  self.folder_btn=ttk.Button(act,text='결과 폴더 열기',command=self.open_result_folder,state='disabled'); self.folder_btn.pack(side='left',expand=True,fill='x',padx=(3,0))
  self.repeat_btn=ttk.Button(prog,text='같은 설정으로 다시 만들기',command=self.repeat_generation,state='disabled'); self.repeat_btn.pack(fill='x',pady=(6,0))
 def _library(self):
  bar=ttk.Frame(self.library); bar.pack(fill='x',pady=(0,8))
  ttk.Button(bar,text='목록 새로고침',command=self.refresh_library).pack(side='left')
  ttk.Button(bar,text='선택곡 삭제',command=self.library_delete_selected,style='JC.Delete.TButton').pack(side='left',padx=5); ttk.Button(bar,text='선택곡 재생',command=self.library_play).pack(side='left',padx=5)
  ttk.Button(bar,text='설정 불러오기',command=self.library_load_settings).pack(side='left',padx=5)
  ttk.Button(bar,text='폴더 열기',command=self.library_open_folder).pack(side='left',padx=5)
  ttk.Button(bar,text='악보 보기',command=self.score_load_library).pack(side='left',padx=5)
  ttk.Button(bar,text='자동 자막',command=self.subtitle_from_library).pack(side='left',padx=5)
  cols=('title','created','voice','bpm','key','length','seed')
  self.song_tree=ttk.Treeview(self.library,columns=cols,show='headings',height=18)
  heads={'title':'제목','created':'생성일시','voice':'보컬','bpm':'BPM','key':'조성','length':'목표 길이','seed':'Seed'}
  widths={'title':220,'created':150,'voice':190,'bpm':65,'key':90,'length':100,'seed':110}
  for c in cols:
   self.song_tree.heading(c,text=heads[c]); self.song_tree.column(c,width=widths[c],anchor='w')
  self.song_tree.pack(fill='both',expand=True)
  self.song_tree.bind('<Double-1>',lambda e:self.library_play())
  player=ttk.LabelFrame(self.library,text='내장 음악 플레이어',padding=10); player.pack(fill='x',pady=(10,0))
  self.player_title=tk.StringVar(value='선택한 곡을 앱 안에서 재생합니다.')
  self.player_status=tk.StringVar(value='정지')
  ttk.Label(player,textvariable=self.player_title,font=('Malgun Gothic',11,'bold')).pack(anchor='w')
  ctl=ttk.Frame(player); ctl.pack(fill='x',pady=(7,2))
  ttk.Button(ctl,text='▶ 재생',command=self.player_play_selected).pack(side='left')
  ttk.Button(ctl,text='⏸ 일시정지',command=self.player_pause).pack(side='left',padx=5)
  ttk.Button(ctl,text='■ 정지',command=self.player_stop).pack(side='left')
  ttk.Button(ctl,text='긴급 전체정지',command=self.player_emergency_stop).pack(side='left',padx=5)
  ttk.Button(ctl,text='↻ 처음부터',command=self.player_restart).pack(side='left',padx=5)
  self.player_volume=tk.DoubleVar(value=0.85)
  ttk.Label(ctl,text='볼륨').pack(side='left',padx=(18,4))
  ttk.Scale(ctl,from_=0.0,to=1.0,variable=self.player_volume,orient='horizontal',length=180,command=lambda _=None:self.player_apply_volume()).pack(side='left')
  ttk.Label(ctl,textvariable=self.player_status).pack(side='right')
  seekrow=ttk.Frame(player); seekrow.pack(fill='x',pady=(5,1))
  self.player_time=tk.StringVar(value='00:00 / 00:00')
  ttk.Label(seekrow,textvariable=self.player_time,width=14).pack(side='left')
  self.player_seek=tk.DoubleVar(value=0.0)
  self.player_seek_scale=ttk.Scale(seekrow,from_=0.0,to=100.0,variable=self.player_seek,orient='horizontal',length=650)
  self.player_seek_scale.pack(side='left',fill='x',expand=True,padx=(5,0))
  self.player_seek_scale.bind('<ButtonPress-1>',self._seek_press)
  self.player_seek_scale.bind('<ButtonRelease-1>',self._seek_release)
  engine_row=ttk.Frame(player); engine_row.pack(fill='x',pady=(4,0))
  self.player_engine_status=tk.StringVar(value='무중단 오디오 엔진 확인 중...')
  ttk.Label(engine_row,textvariable=self.player_engine_status).pack(side='left')
  ttk.Button(engine_row,text='플레이어 엔진 설치/확인',command=self.install_player_engine).pack(side='right')
  ttk.Label(player,text='pygame 오디오 엔진을 사용하면 볼륨 조절 중 재생이 끊기지 않고, 실제 Pause/Resume과 Seek를 사용할 수 있습니다. ffplay는 호환용 예비 엔진으로만 사용합니다.',wraplength=1050,justify='left').pack(anchor='w',pady=(4,0))
  self.after(900,self._check_player_engine)
  self.library_items={}; self.after(700,self.refresh_library)
 def library_delete_selected(self):
  try:
   item=self._library_selected()
   if not item:
    messagebox.showinfo(APP,'삭제할 음악을 먼저 선택해 주세요.'); return
   folder,d,audio=item; folder=Path(folder); info=folder/'song-info.json'
   files=self._library_audio_files(folder,d)
   known=d.get('audio_path') or d.get('audioPath')
   if known:
    try:
     p=Path(known)
     if p.exists() and all(str(p).lower()!=str(x).lower() for x in files): files.insert(0,p)
    except Exception:pass
   title=d.get('title') or folder.name
   legacy=(not known)
   msg=(f'선택한 곡을 라이브러리에서 삭제하시겠습니까?\n\n{title}\n\n'
        f'발견된 음악 파일: {len(files)}개\n'
        + ('과거 항목이라 정확한 원본 경로 기록은 없습니다.\n라이브러리 등록은 확실히 제거합니다.\n' if legacy else '')
        + '\n제작 기록 파일은 삭제하지 않고 삭제 상태만 기록합니다.')
   if not messagebox.askyesno('선택곡 삭제',msg): return
   try:self.player_stop()
   except Exception:pass
   failed=[]
   for p in files:
    try:
     if Path(p).exists(): Path(p).unlink()
    except Exception as e:failed.append((Path(p),e))
   # Crucial: mark metadata hidden even for legacy entries with no discoverable audio.
   try:
    meta=json.loads(info.read_text(encoding='utf-8')) if info.exists() else dict(d)
    meta['library_deleted']=True
    meta['audio_deleted']=True
    meta['deleted_at']=datetime.now().strftime('%Y%m%d-%H%M%S')
    if known: meta['audio_path']=str(known)
    info.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
   except Exception as e:
    messagebox.showerror('삭제 실패','라이브러리 삭제 상태를 저장하지 못했습니다.\n'+str(e)); return
   self.write_log(f'라이브러리 삭제: {title} / 음악파일 {len(files)-len(failed)}개 삭제 / 실패 {len(failed)}개')
   self.refresh_library()
   self.player_title.set('선택한 곡을 앱 안에서 재생합니다.'); self.player_status.set('정지')
   if failed:
    messagebox.showwarning('삭제 완료 / 일부 파일 실패','라이브러리에서는 제거했습니다.\n일부 음악 파일은 삭제하지 못했습니다.\n\n'+'\n'.join(f'{p.name}: {e}' for p,e in failed[:5]))
   else:
    messagebox.showinfo('선택곡 삭제','라이브러리에서 제거했습니다.' + (f'\n음악 파일 {len(files)}개도 삭제했습니다.' if files else '\n과거 항목은 실제 음악 경로 기록이 없어 라이브러리 등록만 제거했습니다.'))
  except Exception as e:
   messagebox.showerror('삭제 실패',f'{type(e).__name__}: {e}')
 def _score(self):
  top=ttk.LabelFrame(self.score,text='악보 만들기 · 빠른 채보 / 보컬 분리 정밀 채보',padding=10); top.pack(fill='x')
  self.score_path=tk.StringVar(value='생성곡 라이브러리에서 곡을 선택한 뒤 악보를 생성하세요.')
  ttk.Label(top,textvariable=self.score_path,wraplength=980,justify='left').pack(fill='x')
  mode=ttk.Frame(top); mode.pack(fill='x',pady=(8,0))
  self.score_mode=tk.StringVar(value='빠른 채보')
  ttk.Label(mode,text='분석 방식').pack(side='left')
  ttk.Radiobutton(mode,text='빠른 채보 (완성 믹스)',value='빠른 채보',variable=self.score_mode).pack(side='left',padx=(10,0))
  ttk.Radiobutton(mode,text='보컬 분리 정밀 채보',value='보컬 분리 정밀 채보',variable=self.score_mode).pack(side='left',padx=(10,0))
  ttk.Button(mode,text='정밀 채보 엔진 설치/확인',command=self.install_score_engine).pack(side='right')
  bar=ttk.Frame(self.score); bar.pack(fill='x',pady=8)
  ttk.Button(bar,text='선택 방식으로 악보 생성',command=self.score_transcribe_library).pack(side='left')
  ttk.Button(bar,text='MusicXML 열기',command=lambda:self.score_open_export('musicxml')).pack(side='left',padx=5)
  ttk.Button(bar,text='MIDI 열기',command=lambda:self.score_open_export('mid')).pack(side='left',padx=5)
  ttk.Button(bar,text='PDF 악보 만들기/열기',command=self.score_pdf).pack(side='left',padx=5)
  ttk.Button(bar,text='MuseScore EXE 선택',command=self.select_musescore).pack(side='left',padx=5)
  ttk.Button(bar,text='악보 폴더 열기',command=self.score_open_folder).pack(side='left',padx=5)
  self.score_status=tk.StringVar(value='대기'); ttk.Label(self.score,textvariable=self.score_status).pack(anchor='w',pady=(0,5))
  self.score_text=tk.Text(self.score,wrap='none',font=('Consolas',11),undo=True)
  y=ttk.Scrollbar(self.score,orient='vertical',command=self.score_text.yview); x=ttk.Scrollbar(self.score,orient='horizontal',command=self.score_text.xview)
  self.score_text.configure(yscrollcommand=y.set,xscrollcommand=x.set); y.pack(side='right',fill='y'); x.pack(side='bottom',fill='x'); self.score_text.pack(fill='both',expand=True)
  ttk.Label(self.score,text='빠른 채보는 완성 믹스를 바로 분석합니다. 정밀 채보는 보컬 Stem을 분리한 뒤 음표 시간축과 원본 가사 행/음절을 순서 정렬하여 MusicXML 가사 위치를 개선합니다. 멜리스마는 연장 표시로 처리합니다.',wraplength=1050,justify='left').pack(anchor='w',pady=(8,0))
  self.current_score_folder=None
 def score_load_library(self):
  self.nb.select(self.score); self.score_transcribe_library()
 def score_open_folder(self):
  if self.current_score_folder and Path(self.current_score_folder).exists(): os.startfile(self.current_score_folder)
 def score_open_export(self,ext):
  if not self.current_score_folder: return
  f=Path(self.current_score_folder)/('score.'+ext)
  if f.exists(): os.startfile(f)
  else: messagebox.showinfo(APP,f.name+' 파일이 아직 없습니다. 먼저 악보를 생성해 주세요.')

 def _subtitles(self):
  top=ttk.LabelFrame(self.subtitles,text='한국어 가사 시간 맞추기 · SRT 자동 생성',padding=10); top.pack(fill='x')
  self.subtitle_path=tk.StringVar(value='생성곡 라이브러리에서 곡을 선택하세요.')
  ttk.Label(top,textvariable=self.subtitle_path,wraplength=1000,justify='left').pack(fill='x')
  row=ttk.Frame(top); row.pack(fill='x',pady=(8,0))
  self.subtitle_mode=tk.StringVar(value='보컬 분리 정밀 정렬')
  ttk.Radiobutton(row,text='빠른 정렬 (완성 믹스)',value='빠른 정렬',variable=self.subtitle_mode).pack(side='left')
  ttk.Radiobutton(row,text='보컬 분리 정밀 정렬',value='보컬 분리 정밀 정렬',variable=self.subtitle_mode).pack(side='left',padx=(12,0))
  ttk.Button(row,text='한국어 정렬 엔진 설치/확인',command=self.subtitle_asr_install).pack(side='right',padx=(5,0))
  ttk.Button(row,text='가사 시간 맞추기 + SRT 생성',command=self.subtitle_generate).pack(side='right')
  offsetrow=ttk.Frame(top); offsetrow.pack(fill='x',pady=(8,0))
  ttk.Label(offsetrow,text='자막 전체 오프셋(초)').pack(side='left')
  self.subtitle_offset=tk.DoubleVar(value=0.0)
  ttk.Spinbox(offsetrow,from_=-2.0,to=2.0,increment=0.1,textvariable=self.subtitle_offset,width=7).pack(side='left',padx=6)
  ttk.Label(offsetrow,text='(+ 값은 자막을 늦게, - 값은 빠르게 표시)').pack(side='left')
  bar=ttk.Frame(self.subtitles); bar.pack(fill='x',pady=8)
  ttk.Button(bar,text='1줄 SRT 열기',command=lambda:self.subtitle_open('subtitles_1line.srt')).pack(side='left')
  ttk.Button(bar,text='2줄 SRT 열기',command=lambda:self.subtitle_open('subtitles_2line.srt')).pack(side='left',padx=5)
  ttk.Button(bar,text='자막 폴더 열기',command=self.subtitle_open_folder).pack(side='left',padx=5)
  ttk.Button(bar,text='동기화 후 악보 다시 만들기',command=self.score_transcribe_library).pack(side='left',padx=5)
  self.subtitle_status=tk.StringVar(value='대기'); ttk.Label(self.subtitles,textvariable=self.subtitle_status).pack(anchor='w')
  self.subtitle_text=tk.Text(self.subtitles,wrap='word',font=('Malgun Gothic',11)); self.subtitle_text.pack(fill='both',expand=True,pady=(5,0))
  ttk.Label(self.subtitles,text='V2.9.6 최종 정렬은 확정된 Whisper 가사 앵커를 유지하면서 보컬 Stem의 실제 발성 시작과 호흡/무음 경계를 2차 검증합니다. 자막을 임의로 앞당기지 않으며, 실제 발성보다 이른 시작을 억제합니다. 2줄 SRT는 검증된 1줄 시간에서 생성합니다.',wraplength=1050,justify='left').pack(anchor='w',pady=(8,0))
  self.current_subtitle_folder=None
 def subtitle_from_library(self):
  item=self._library_selected()
  if not item: messagebox.showinfo(APP,'생성곡 라이브러리에서 곡을 먼저 선택해 주세요.'); return
  self.current_subtitle_folder=Path(item[0]); self.subtitle_path.set(str(item[0])); self.nb.select(self.subtitles)
 def subtitle_asr_install(self):
  def run():
   try:
    py=self.runtime_python()
    if not py or not Path(py).exists(): raise RuntimeError('공용 Runtime Python을 찾지 못했습니다.')
    self.after(0,lambda:self.subtitle_status.set('한국어 정렬 엔진 설치/확인 중...'))
    # 공용 Runtime은 uv로 만든 venv라 pip 모듈이 없을 수 있습니다.
    # 1) pip 확인 -> 2) ensurepip 복구 -> 3) 그래도 없으면 공용 uv로 설치합니다.
    pipcheck=subprocess.run([str(py),'-m','pip','--version'],capture_output=True,text=True,encoding='utf-8',errors='replace',**self._hidden_kw())
    if pipcheck.returncode:
     self.after(0,lambda:self.subtitle_status.set('공용 Runtime의 pip 자동 복구 중...'))
     ep=subprocess.run([str(py),'-m','ensurepip','--upgrade'],capture_output=True,text=True,encoding='utf-8',errors='replace',**self._hidden_kw())
     pipcheck=subprocess.run([str(py),'-m','pip','--version'],capture_output=True,text=True,encoding='utf-8',errors='replace',**self._hidden_kw())
    if pipcheck.returncode==0:
     cp=subprocess.run([str(py),'-m','pip','install','-U','faster-whisper','hf_xet'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1800,**self._hidden_kw())
    else:
     rt=Path(py).parents[2]; uv=rt/'uv.exe'
     if not uv.exists():
      raise RuntimeError('pip 자동 복구에 실패했고 공용 Runtime의 uv.exe도 찾지 못했습니다.\n'+(pipcheck.stdout+'\n'+pipcheck.stderr)[-1500:])
     self.after(0,lambda:self.subtitle_status.set('uv를 사용해 한국어 정렬 엔진 설치 중...'))
     cp=subprocess.run([str(uv),'pip','install','--python',str(py),'faster-whisper','hf_xet'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1800,**self._hidden_kw())
    if cp.returncode: raise RuntimeError((cp.stdout+'\n'+cp.stderr)[-3000:])
    verify=subprocess.run([str(py),'-c','import faster_whisper; print(\"ASR OK\")'],capture_output=True,text=True,encoding='utf-8',errors='replace',**self._hidden_kw())
    if verify.returncode: raise RuntimeError('설치는 끝났지만 faster-whisper 실행 확인에 실패했습니다.\n'+(verify.stdout+'\n'+verify.stderr)[-2000:])
    self.after(0,lambda:self.subtitle_status.set('한국어 정렬 엔진 준비 완료 · 최초 정렬 때 Whisper small 모델을 자동 준비합니다.'))
   except Exception as e:self.after(0,lambda e=e:messagebox.showerror(APP,'정렬 엔진 설치 실패: '+str(e)))
  threading.Thread(target=run,daemon=True).start()
 def subtitle_generate(self):
  item=self._library_selected()
  if not item: messagebox.showinfo(APP,'생성곡 라이브러리에서 곡을 먼저 선택해 주세요.'); return
  folder,d,audio=item; folder=Path(folder); wav=next(iter(sorted(folder.glob('*.wav'))),None)
  if not wav: messagebox.showinfo(APP,'자막 분석용 WAV 파일을 찾지 못했습니다.'); return
  lyr=folder/'lyrics.txt'
  if not lyr.exists(): messagebox.showinfo(APP,'lyrics.txt를 찾지 못했습니다.'); return
  self.current_subtitle_folder=folder; self.subtitle_path.set(str(wav)); self.subtitle_status.set('가사 시간 정렬 준비 중...')
  def run():
   try:
    py=self.runtime_python()
    if not py or not Path(py).exists(): raise RuntimeError('공용 Runtime Python을 찾지 못했습니다.')
    source=wav
    if self.subtitle_mode.get()=='보컬 분리 정밀 정렬':
     self.after(0,lambda:self.subtitle_status.set('보컬 Stem 분리 중...'))
     source=self._separate_vocals(py,wav,folder)
    self.after(0,lambda:self.subtitle_status.set('한국어 단어 시간을 인식하고 원본 가사를 강제정렬하고 있습니다...'))
    cp=subprocess.run([str(py),str(BASE/'lyric_aligner_asr.py'),str(source),str(lyr),str(folder),str(float(self.subtitle_offset.get()))],capture_output=True,text=True,encoding='utf-8',errors='replace',cwd=BASE,**self._hidden_kw())
    if cp.returncode: raise RuntimeError((cp.stdout+'\n'+cp.stderr).strip()[-3000:])
    srt=(folder/'subtitles_1line.srt').read_text(encoding='utf-8-sig',errors='replace')
    def done():
     self.subtitle_text.delete('1.0','end'); self.subtitle_text.insert('1.0',srt); self.subtitle_status.set('완료 · 1줄/2줄 SRT + 악보용 가사 시간정보 저장'); self.write_log('가사 시간 정렬/SRT 완료: '+str(folder))
    self.after(0,done)
   except Exception as e:
    self.after(0,lambda:self.subtitle_status.set('자막 생성 실패')); self.after(0,lambda e=e:messagebox.showerror(APP,'자동 자막 생성 실패: '+str(e)))
  threading.Thread(target=run,daemon=True).start()
 def subtitle_open(self,name):
  if not self.current_subtitle_folder: return
  f=Path(self.current_subtitle_folder)/name
  if f.exists(): os.startfile(f)
  else: messagebox.showinfo(APP,name+' 파일이 아직 없습니다.')
 def subtitle_open_folder(self):
  if self.current_subtitle_folder and Path(self.current_subtitle_folder).exists(): os.startfile(self.current_subtitle_folder)
 def _musescore_candidates(self):
  c=[]
  cfg=SETTINGS/'musescore.json'
  try:
   if cfg.exists():
    x=json.loads(cfg.read_text(encoding='utf-8')).get('exe','')
    if x: c.append(Path(x))
  except: pass
  for base in [Path(os.environ.get('ProgramFiles','C:/Program Files')),Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))]:
   for pat in ['MuseScore 4/bin/MuseScore4.exe','MuseScore 4/bin/mscore4.exe','MuseScore 3/bin/MuseScore3.exe','MuseScore 3/bin/mscore.exe']:
    c.append(base/pat)
  return c
 def find_musescore(self):
  for x in self._musescore_candidates():
   if x.exists(): return x
  return None
 def select_musescore(self):
  f=filedialog.askopenfilename(title='MuseScore 실행 파일 선택',filetypes=[('MuseScore EXE','*.exe'),('실행 파일','*.exe')])
  if not f: return
  SETTINGS.mkdir(parents=True,exist_ok=True); (SETTINGS/'musescore.json').write_text(json.dumps({'exe':f},ensure_ascii=False,indent=2),encoding='utf-8')
  messagebox.showinfo(APP,'MuseScore 경로를 저장했습니다.\n'+f)
 def _make_pdf(self,folder,quiet=False):
  folder=Path(folder); xml=folder/'score.musicxml'; pdf=folder/'score.pdf'
  if not xml.exists():
   if not quiet: messagebox.showinfo(APP,'먼저 악보를 생성해 주세요.')
   return False
  ms=self.find_musescore()
  if not ms:
   if not quiet: messagebox.showinfo(APP,'PDF 악보는 MuseScore의 악보 렌더링을 사용합니다.\n「MuseScore EXE 선택」에서 설치된 MuseScore4.exe를 한 번 선택해 주세요.\nMusicXML/MIDI는 현재 그대로 사용할 수 있습니다.')
   return False
  try:
   cp=subprocess.run([str(ms),'-o',str(pdf),str(xml)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180,**self._hidden_kw())
   if cp.returncode or not pdf.exists(): raise RuntimeError((cp.stdout+'\n'+cp.stderr).strip()[-2000:])
   return True
  except Exception as e:
   if not quiet: messagebox.showerror(APP,'PDF 악보 생성 실패: '+str(e))
   return False
 def score_pdf(self):
  if not self.current_score_folder:
   messagebox.showinfo(APP,'생성곡 라이브러리에서 곡을 선택하고 악보를 먼저 생성해 주세요.'); return
  folder=Path(self.current_score_folder); pdf=folder/'score.pdf'
  if not pdf.exists() and not self._make_pdf(folder): return
  if pdf.exists(): os.startfile(pdf)
 def _hidden_kw(self):
  kw={}
  if os.name=='nt':
   kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0); si=subprocess.STARTUPINFO(); si.dwFlags|=subprocess.STARTF_USESHOWWINDOW; si.wShowWindow=0; kw['startupinfo']=si
  return kw
 def _demucs_ready(self,py):
  try:
   cp=subprocess.run([str(py),'-c','import demucs; print(demucs.__version__ if hasattr(demucs,"__version__") else "OK")'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30,**self._hidden_kw())
   return cp.returncode==0
  except: return False
 def install_score_engine(self):
  py=self.runtime_python()
  if not py or not Path(py).exists(): messagebox.showerror(APP,'공용 Runtime Python을 찾지 못했습니다.'); return
  if self._demucs_ready(py): messagebox.showinfo(APP,'정밀 채보 엔진(Demucs)이 이미 준비되어 있습니다.'); return
  if not messagebox.askyesno(APP,'정밀 채보 엔진 Demucs를 공용 Runtime에 설치합니다. 인터넷 연결이 필요합니다. 계속할까요?'): return
  self.score_status.set('정밀 채보 엔진 설치 중...')
  def run():
   try:
    cmd=[str(py),'-m','pip','install','demucs']
    cp=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1200,**self._hidden_kw())
    if cp.returncode:
     rt=Path(py).parents[2]; uv=rt/'uv.exe'
     if uv.exists(): cp=subprocess.run([str(uv),'pip','install','--python',str(py),'demucs'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1200,**self._hidden_kw())
    if cp.returncode or not self._demucs_ready(py): raise RuntimeError((cp.stdout+'\n'+cp.stderr).strip()[-3000:])
    self.after(0,lambda:self.score_status.set('정밀 채보 엔진 준비 완료'))
    self.after(0,lambda:messagebox.showinfo(APP,'Demucs 설치가 완료되었습니다. 정밀 채보를 사용할 수 있습니다.'))
   except Exception as e:
    self.after(0,lambda:self.score_status.set('정밀 채보 엔진 설치 실패'))
    self.after(0,lambda e=e:messagebox.showerror(APP,'설치 실패: '+str(e)))
  threading.Thread(target=run,daemon=True).start()
 def _separate_vocals(self,py,wav,folder):
  if not self._demucs_ready(py): raise RuntimeError('정밀 채보 엔진(Demucs)이 설치되어 있지 않습니다. 「정밀 채보 엔진 설치/확인」을 먼저 눌러 주세요.')
  stemroot=folder/'score_stems'; stemroot.mkdir(parents=True,exist_ok=True)
  cmd=[str(py),'-m','demucs','--two-stems=vocals','-n','htdemucs','--device','cuda','-o',str(stemroot),str(wav)]
  cp=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=3600,**self._hidden_kw())
  if cp.returncode:
   # GPU 메모리/환경 문제 시 CPU로 한 번 자동 재시도
   cmd[cmd.index('cuda')]='cpu'
   cp=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=7200,**self._hidden_kw())
  if cp.returncode: raise RuntimeError('보컬 분리 실패: '+(cp.stdout+'\n'+cp.stderr).strip()[-3000:])
  vocals=list(stemroot.rglob('vocals.wav'))
  if not vocals: raise RuntimeError('Demucs 실행은 끝났지만 vocals.wav를 찾지 못했습니다.')
  target=folder/'vocals_for_score.wav'; shutil.copy2(vocals[0],target); return target
 def score_transcribe_library(self):
  item=self._library_selected()
  if not item: messagebox.showinfo(APP,'생성곡 라이브러리에서 곡을 먼저 선택해 주세요.'); return
  folder,d,audio=item; folder=Path(folder)
  wav=next(iter(sorted(folder.glob('*.wav'))),None)
  if not wav:
   messagebox.showinfo(APP,'악보 분석용 WAV 파일을 찾지 못했습니다.'); return
  self.current_score_folder=folder; self.nb.select(self.score); mode=self.score_mode.get(); self.score_status.set(('보컬을 분리하고 있습니다...' if mode=='보컬 분리 정밀 채보' else '완성 음원을 분석하고 있습니다...')); self.score_path.set(str(wav))
  def run():
   try:
    py=self.runtime_python()
    if not py or not Path(py).exists(): raise RuntimeError('공용 Runtime Python을 찾지 못했습니다.')
    source=wav
    if mode=='보컬 분리 정밀 채보':
     source=self._separate_vocals(py,wav,folder)
     self.after(0,lambda:self.score_status.set('보컬 분리 완료 · 멜로디 정밀 분석 중...'))
    helper=BASE/'score_transcriber.py'; align=folder/'lyric-alignment.json'; cmd=[str(py),str(helper),str(source),str(folder),str(d.get('bpm',70) or 70),str(d.get('key','C Major')),str(folder/'lyrics.txt'),str(d.get('title',folder.parent.name)),str(align) if align.exists() else '']
    cp=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',cwd=BASE,**self._hidden_kw())
    if cp.returncode: raise RuntimeError((cp.stdout+'\n'+cp.stderr).strip()[-3000:])
    abc=folder/'score.abc'; txt=abc.read_text(encoding='utf-8',errors='replace') if abc.exists() else cp.stdout
    def done():
     self.score_text.delete('1.0','end'); self.score_text.insert('1.0',txt); pdfok=self._make_pdf(folder,quiet=True); self.score_status.set(('정밀 악보 초안 생성 완료' if mode=='보컬 분리 정밀 채보' else '빠른 악보 초안 생성 완료')+(' · ABC / MusicXML / MIDI / PDF 저장' if pdfok else ' · ABC / MusicXML / MIDI 저장 · PDF는 MuseScore 선택 후 생성 가능')); self.score_path.set(str(folder)); self.write_log(mode+' 완료: '+str(folder))
    self.after(0,done)
   except Exception as e:
    self.after(0,lambda:self.score_status.set('악보 생성 실패')); self.after(0,lambda e=e:messagebox.showerror(APP,'악보 생성 실패: '+str(e)))
  threading.Thread(target=run,daemon=True).start()
 def _format_created_at(self,value,audio=None):
  try:
   if value:
    txt=str(value).strip().replace('T',' ')
    txt=txt.replace('Z','')
    if '.' in txt: txt=txt.split('.')[0]
    if len(txt)>=16: return txt[:16].replace('-','.')
   if audio and Path(audio).exists():
    return time.strftime('%Y.%m.%d %H:%M',time.localtime(Path(audio).stat().st_mtime))
  except Exception:pass
  return '-'

 def _format_library_created(self,value,folder=None,audio=None):
  try:
   raw=str(value or '').strip()
   # Supports 20261005-080912, 20261005_080912, ISO dates, etc.
   digits=''.join(ch for ch in raw if ch.isdigit())
   if len(digits)>=12:
    return f'{digits[0:4]}.{digits[4:6]}.{digits[6:8]} {digits[8:10]}:{digits[10:12]}'
   if raw:
    txt=raw.replace('T',' ').replace('Z','')
    if len(txt)>=16:return txt[:16].replace('-','.')
   target=Path(audio) if audio else None
   if target and target.exists():
    return time.strftime('%Y.%m.%d %H:%M',time.localtime(target.stat().st_mtime))
   if folder and Path(folder).exists():
    return time.strftime('%Y.%m.%d %H:%M',time.localtime(Path(folder).stat().st_mtime))
  except Exception:pass
  return '-'

 def _library_audio_files(self,folder,d=None):
  folder=Path(folder)
  exts={'.mp3','.wav','.flac','.m4a','.ogg','.aac'}
  found=[]
  # 1) metadata may contain an explicit output/audio path
  if isinstance(d,dict):
   for key in ('audio','audio_path','audioPath','output','output_path','outputPath','file','file_path','filePath'):
    v=d.get(key)
    if not v: continue
    try:
     p=Path(v)
     candidates=[p,folder/p,SONGS/p] if not p.is_absolute() else [p]
     for q in candidates:
      if q.exists() and q.is_file() and q.suffix.lower() in exts:
       found.append(q.resolve())
    except Exception:pass
  # 2) YuE2 output may be in a child directory, so search recursively.
  try:
   for p in folder.rglob('*'):
    if p.is_file() and p.suffix.lower() in exts:
     found.append(p.resolve())
  except Exception:pass
  # unique, stable order
  out=[]; seen=set()
  for p in found:
   k=str(p).lower()
   if k not in seen:
    seen.add(k); out.append(p)
  return out

 def _find_library_audio(self,folder,d=None):
  files=self._library_audio_files(folder,d)
  return files[0] if files else None

 def refresh_library(self):
  if not hasattr(self,'song_tree'): return
  for x in self.song_tree.get_children(): self.song_tree.delete(x)
  self.library_items={}; rows=[]
  for info in SONGS.rglob('song-info.json') if SONGS.exists() else []:
   try:
    d=json.loads(info.read_text(encoding='utf-8')); folder=info.parent
    # Explicitly deleted/hidden library records never reappear.
    if d.get('library_deleted') is True or d.get('audio_deleted') is True:
     continue
    audio=self._find_library_audio(folder,d)
    known=d.get('audio_path') or d.get('audioPath')
    if known and not Path(known).exists(): continue
    created=self._format_library_created(d.get('created_at') or d.get('createdAt'),folder,audio)
    stamp=(Path(audio).stat().st_mtime if audio and Path(audio).exists() else info.stat().st_mtime)
    rows.append((stamp,created,folder,d,audio))
   except Exception as e:self.write_log('라이브러리 항목 읽기 오류: '+str(info)+' / '+str(e))
  for idx,(_,created,folder,d,audio) in enumerate(sorted(rows,key=lambda x:x[0],reverse=True)):
   iid=f's{idx}'
   vals=(d.get('title',folder.parent.name),created,d.get('voice',''),d.get('bpm',''),d.get('key',''),d.get('target_length',''),d.get('seed','랜덤'))
   self.song_tree.insert('', 'end', iid=iid, values=vals); self.library_items[iid]=(folder,d,audio)
 def _library_selected(self):
  sel=self.song_tree.selection() if hasattr(self,'song_tree') else ()
  return self.library_items.get(sel[0]) if sel else None
 def _player_audio_from_selected(self):
  item=self._library_selected()
  if not item:return None
  audio=item[2]
  if audio and Path(audio).exists():return Path(audio)
  folder=Path(item[0])
  return next(iter(sorted(folder.glob('*.wav'))),None) or next(iter(sorted(folder.glob('*.mp3'))),None)

 def _shared_runtime_python(self):
  # Prefer the known shared YuE2 runtime, independent of how jc_studio.py itself was launched.
  candidates=[
   JC_HOME/'Engine'/'py-runtime'/'venv'/'Scripts'/'python.exe',
  ]
  try:
   rp=self.runtime_python()
   if rp:candidates.insert(0,Path(rp))
  except Exception:pass
  for q in candidates:
   if q and q.exists():return q
  return None

 def _check_player_engine(self):
  try:
   import pygame
   if not pygame.mixer.get_init():
    pygame.mixer.init(frequency=44100,size=-16,channels=2,buffer=1024)
   self.player_backend='pygame'
   self.player_runtime_python=Path(sys.executable)
   if hasattr(self,'player_engine_status'):
    self.player_engine_status.set('오디오 엔진: 준비 완료 · 앱 내부 pygame')
   return True
  except Exception as e:
   self.player_backend=None
   if hasattr(self,'player_engine_status'):
    self.player_engine_status.set('오디오 엔진 오류 · RUN_jC-STUDIO.bat로 실행')
   return False

 def install_player_engine(self):
  def run():
   try:
    py=self.runtime_python()
    if not py or not Path(py).exists():raise RuntimeError('공용 Runtime Python을 찾지 못했습니다.')
    self.after(0,lambda:self.player_engine_status.set('pygame 오디오 엔진 설치 중...'))
    cp=subprocess.run([str(py),'-m','pip','install','pygame==2.6.1'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=600,**self._hidden_kw())
    if cp.returncode:
     # uv-created runtime may not expose pip; recover using ensurepip.
     subprocess.run([str(py),'-m','ensurepip','--upgrade'],capture_output=True,text=True,encoding='utf-8',errors='replace',**self._hidden_kw())
     cp=subprocess.run([str(py),'-m','pip','install','pygame==2.6.1'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=600,**self._hidden_kw())
    if cp.returncode:raise RuntimeError((cp.stdout+'\n'+cp.stderr)[-2500:])
    self.after(0,lambda:messagebox.showinfo(APP,'무중단 플레이어 엔진 설치가 완료되었습니다.\n프로그램을 한 번 종료한 뒤 다시 실행해 주세요.'))
   except Exception as e:self.after(0,lambda e=e:messagebox.showerror(APP,'플레이어 엔진 설치 실패: '+str(e)))
  threading.Thread(target=run,daemon=True).start()

 def _cleanup_jcstudio_ffplay(self):
  # Old builds launched ffplay detached. Kill only ffplay instances playing files under jC-STUDIO\Songs.
  if os.name!='nt':return
  try:
   ps=("Get-CimInstance Win32_Process | Where-Object { "
       "$_.Name -ieq 'ffplay.exe' -and $_.CommandLine -like '*jC-STUDIO\\\\Songs*' } | "
       "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
   subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],
                  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10,**self._hidden_kw())
  except Exception:pass

 def _cleanup_stale_player_bridges(self):
  if os.name!='nt':return
  try:
   ps=("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*runtime_player_bridge.py*' } | "
       "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
   subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],
                  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10,**self._hidden_kw())
  except Exception:pass

 def _ensure_runtime_player_bridge(self):
  if self.player_backend!='runtime-pygame':return False
  proc=getattr(self,'runtime_player_proc',None)
  if proc and proc.poll() is None and proc.stdin and not proc.stdin.closed:return True
  self._cleanup_jcstudio_ffplay()
  self._cleanup_stale_player_bridges()
  py=getattr(self,'player_runtime_python',None) or self._shared_runtime_python()
  helper=BASE/'runtime_player_bridge.py'
  if not py or not Path(py).exists() or not helper.exists():return False
  kw={'stdin':subprocess.PIPE,'stdout':subprocess.PIPE,'stderr':subprocess.DEVNULL,
      'text':True,'encoding':'utf-8','errors':'replace','bufsize':1}
  if os.name=='nt':
   kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
   si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;kw['startupinfo']=si
  proc=subprocess.Popen([str(py),str(helper),str(os.getpid())],**kw)
  line=proc.stdout.readline().strip()
  if not line.startswith('READY'):
   try:proc.kill()
   except Exception:pass
   return False
  self.runtime_player_proc=proc
  return True

 def _bridge_send(self,obj):
  import json
  if not self._ensure_runtime_player_bridge():return False
  proc=self.runtime_player_proc
  try:
   proc.stdin.write(json.dumps(obj,ensure_ascii=False)+'\n')
   proc.stdin.flush()
   return proc.poll() is None
  except Exception:
   return False

 def _shutdown_runtime_player_bridge(self):
  proc=getattr(self,'runtime_player_proc',None)
  if not proc:return
  try:
   if proc.poll() is None:
    import json
    try:
     proc.stdin.write(json.dumps({'cmd':'quit'})+'\n');proc.stdin.flush()
    except Exception:pass
    try:proc.wait(timeout=1.5)
    except Exception:
     proc.terminate()
     try:proc.wait(timeout=1)
     except Exception:proc.kill()
  except Exception:pass
  self.runtime_player_proc=None

 def _ffplay_path(self):
  import shutil as _shutil
  found=_shutil.which('ffplay')
  if found:return Path(found)
  for c in [BASE/'ffplay.exe',self.runtime_root()/'ffplay.exe',self.runtime_root()/'bin'/'ffplay.exe',self.runtime_root()/'ffmpeg'/'bin'/'ffplay.exe']:
   if c and Path(c).exists():return Path(c)
  return None

 def _ffprobe_path(self):
  import shutil as _shutil
  found=_shutil.which('ffprobe')
  if found:return Path(found)
  ff=self._ffplay_path()
  if ff:
   q=ff.with_name('ffprobe.exe')
   if q.exists():return q
  return None

 def _audio_duration(self,audio):
  try:
   if self._check_player_engine() and self.player_backend=='pygame':
    import pygame
    return float(pygame.mixer.Sound(str(audio)).get_length())
  except Exception:pass
  try:
   pr=self._ffprobe_path()
   if pr:
    cp=subprocess.run([str(pr),'-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(audio)],capture_output=True,text=True,**self._hidden_kw())
    if cp.returncode==0:return max(0.0,float(cp.stdout.strip()))
   if Path(audio).suffix.lower()=='.wav':
    import wave
    with wave.open(str(audio),'rb') as w:return w.getnframes()/float(w.getframerate())
  except Exception:pass
  return 0.0

 def _fmt_time(self,sec):
  sec=max(0,int(sec or 0));return f'{sec//60:02d}:{sec%60:02d}'

 def _current_player_position(self):
  if self.player_backend=='runtime-pygame':
   if self.player_paused:return self.player_position
   pos=self.player_base_position+(max(0.0,time.time()-self.player_started_at) if self.player_started_at else 0.0)
   return min(pos,self.player_duration) if self.player_duration else pos
  if self.player_backend=='pygame':
   try:
    import pygame
    ms=pygame.mixer.music.get_pos()
    if ms>=0 and not self.player_paused:return min(self.player_duration or 1e12,self.player_base_position+ms/1000.0)
    return self.player_position
   except Exception:return self.player_position
  pos=float(getattr(self,'player_position',0.0) or 0.0)
  if getattr(self,'player_started_at',None) is not None and getattr(self,'player_proc',None):
   pos+=max(0.0,time.time()-self.player_started_at)
  return min(pos,self.player_duration) if self.player_duration else pos

 def _start_internal_player(self,audio,start_at=0.0):
  audio=Path(audio); self.player_audio=audio
  if self._check_player_engine() and self.player_backend=='runtime-pygame':
   self.player_duration=self._audio_duration(audio)
   self.player_position=max(0.0,min(float(start_at or 0),self.player_duration or float(start_at or 0)))
   self.player_base_position=self.player_position
   vol=max(0.0,min(1.0,float(self.player_volume.get())))
   if self._bridge_send({'cmd':'play','path':str(audio),'start':self.player_position,'volume':vol}):
    self.player_proc='runtime-pygame'; self.player_paused=False; self.player_started_at=time.time()
    self.player_status.set('재생 중'); self._player_update_ui(); self.after(250,self._player_watch); return
  if self.player_backend=='pygame':
   import pygame
   try:
    if pygame.mixer.music.get_busy() or self.player_paused:pygame.mixer.music.stop()
   except Exception:pass
   self.player_duration=self._audio_duration(audio)
   self.player_position=max(0.0,min(float(start_at or 0),self.player_duration or float(start_at or 0)))
   self.player_base_position=self.player_position
   pygame.mixer.music.load(str(audio))
   pygame.mixer.music.set_volume(max(0.0,min(1.0,float(self.player_volume.get()))))
   try: pygame.mixer.music.play(loops=0,start=self.player_position)
   except Exception:
    pygame.mixer.music.play()
    if self.player_position>0:
     try:pygame.mixer.music.set_pos(self.player_position)
     except Exception:pass
   self.player_backend='pygame'; self.player_proc='pygame'; self.player_paused=False
   self.player_started_at=time.time(); self.player_status.set('재생 중')
   self._player_update_ui(); self.after(250,self._player_watch); return

  # Compatibility fallback: ffplay. Live volume is unavailable here.
  self.player_stop(keep_audio=True,keep_position=True)
  self.player_duration=self._audio_duration(audio)
  self.player_position=max(0.0,float(start_at or 0))
  ffplay=self._ffplay_path()
  if ffplay:
   kw={'stdout':subprocess.DEVNULL,'stderr':subprocess.DEVNULL}
   if os.name=='nt':
    kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;kw['startupinfo']=si
   cmd=[str(ffplay),'-nodisp','-autoexit','-loglevel','quiet']
   if self.player_position>0:cmd+=['-ss',f'{self.player_position:.3f}']
   cmd+=['-volume',str(int(float(self.player_volume.get())*100)),str(audio)]
   self.player_proc=subprocess.Popen(cmd,**kw);self.player_started_at=time.time();self.player_status.set('재생 중 · 호환 엔진')
   self.after(250,self._player_watch);self._player_update_ui();return
  messagebox.showinfo(APP,'플레이어 엔진을 설치해 주세요.')

 def _player_watch(self):
  if self.player_backend=='runtime-pygame':
   if not self.player_paused and self.player_duration and self._current_player_position()>=self.player_duration-0.15:
    self.player_position=self.player_duration; self.player_proc=None; self.player_started_at=None; self.player_status.set('정지')
  elif self.player_backend=='pygame':

   try:
    import pygame
    if not self.player_paused and self.player_proc and not pygame.mixer.music.get_busy():
     self.player_position=self.player_duration;self.player_base_position=self.player_duration
     self.player_proc=None;self.player_started_at=None;self.player_status.set('정지')
   except Exception:pass
  else:
   p=getattr(self,'player_proc',None)
   if hasattr(p,'poll') and p.poll() is not None and not self.player_paused:
    self.player_position=self.player_duration or self._current_player_position();self.player_proc=None;self.player_started_at=None;self.player_status.set('정지')
  self._player_update_ui()
  if self.player_proc:self.after(250,self._player_watch)

 def _player_update_ui(self):
  try:
   pos=self._current_player_position();dur=float(self.player_duration or 0)
   self.player_position=pos
   if hasattr(self,'player_time'):self.player_time.set(f'{self._fmt_time(pos)} / {self._fmt_time(dur)}')
   if hasattr(self,'player_seek') and not self.player_seeking:self.player_seek.set((pos/dur*100.0) if dur>0 else 0.0)
  except Exception:pass

 def _seek_press(self,event=None):
  self.player_seeking=True

 def _seek_release(self,event=None):
  self.player_seeking=False
  if not self.player_audio:return
  dur=float(self.player_duration or self._audio_duration(self.player_audio))
  if dur<=0:return
  newpos=max(0.0,min(dur,dur*float(self.player_seek.get())/100.0))
  was_paused=self.player_paused
  self._start_internal_player(self.player_audio,newpos)
  if was_paused:self.player_pause()

 def player_play_selected(self):
  if self.player_backend=='runtime-pygame' and self.player_paused:
   self._bridge_send({'cmd':'resume'}); self.player_paused=False; self.player_started_at=time.time(); self.player_base_position=self.player_position
   self.player_proc='runtime-pygame'; self.player_status.set('재생 중'); self.after(250,self._player_watch); return
  if self.player_backend=='pygame' and self.player_paused:
   try:
    import pygame
    pygame.mixer.music.unpause();self.player_paused=False;self.player_proc='pygame';self.player_status.set('재생 중');self.after(250,self._player_watch);return
   except Exception:pass
  audio=self._player_audio_from_selected()
  if not audio:
   messagebox.showinfo(APP,'선택한 곡의 WAV/MP3 파일을 찾지 못했습니다.');return
  self.player_title.set(Path(audio).name);self._start_internal_player(audio,0.0)

 def player_pause(self):
  if self.player_backend!='pygame':return
  try:
   import pygame
   if self.player_paused:
    pygame.mixer.music.unpause()
    self.player_paused=False
    self.player_started_at=time.time()
    self.player_base_position=self.player_position
    self.player_status.set('재생 중')
   else:
    self.player_position=self._current_player_position()
    self.player_base_position=self.player_position
    pygame.mixer.music.pause()
    self.player_paused=True
    self.player_started_at=None
    self.player_status.set('일시정지')
   self._player_update_ui()
  except Exception:
   self.player_status.set('일시정지 제어 오류')

 def player_emergency_stop(self):
  try:
   import pygame
   if pygame.mixer.get_init():
    pygame.mixer.music.stop()
  except Exception:pass
  self.player_proc=None
  self.player_paused=False
  self.player_started_at=None
  self.player_position=0.0
  self.player_base_position=0.0
  if hasattr(self,'player_status'):self.player_status.set('전체 정지')
  self._player_update_ui()

 def player_restart(self):
  audio=self.player_audio or self._player_audio_from_selected()
  if audio and Path(audio).exists():self._start_internal_player(audio,0.0)

 def player_apply_volume(self):
  try:
   vol=max(0.0,min(1.0,float(self.player_volume.get())))
   import pygame
   if pygame.mixer.get_init():
    pygame.mixer.music.set_volume(vol)
   if hasattr(self,'player_status') and self.player_proc:
    self.player_status.set(f'재생 중 · 볼륨 {int(round(vol*100))}%')
  except Exception:
   if hasattr(self,'player_status'):self.player_status.set('볼륨 조절 오류')

 def player_stop(self,keep_audio=False,keep_position=False):
  try:
   import pygame
   if pygame.mixer.get_init(): pygame.mixer.music.stop()
  except Exception:pass
  self.player_proc=None;self.player_paused=False;self.player_started_at=None
  if not keep_position:
   self.player_position=0.0;self.player_base_position=0.0
  if not keep_audio:self.player_audio=None
  if hasattr(self,'player_status'):self.player_status.set('정지')
  self._player_update_ui()

 def library_play(self):
  self.player_play_selected()

 def library_open_folder(self):
  item=self._library_selected()
  if item and Path(item[0]).exists(): os.startfile(item[0])
 def library_load_settings(self):
  item=self._library_selected()
  if not item: return
  folder,d,audio=item
  self.titlev.set(d.get('title','새 찬양')); self.voice.set(d.get('voice',self.voice.get())); self.bpm.set(d.get('bpm',self.bpm.get())); self.key.set(d.get('key',self.key.get())); self.length.set(d.get('target_length',self.length.get())); self.genre.set(d.get('genre',self.genre.get())); self.instrument.set(d.get('instrument_preset',self.instrument.get()))
  seed=d.get('seed'); self.seed.set('랜덤' if seed is None else str(seed))
  self.lyrics.delete('1.0','end'); self.lyrics.insert('1.0',d.get('lyrics',''))
  self.prompt_mode.set('직접 붙여넣기'); self.set_style_text(d.get('style',''),False)
  adv=d.get('advanced') or {}; amap={'temperature':'temperature','topP':'top_p','topK':'top_k','repetitionPenalty':'repetition_penalty','cfgScale':'cfg_scale','odeSteps':'ode_steps'}
  for k,v in amap.items():
   if k in adv and v in self.vars: self.vars[v].set(str(adv[k]))
  self.nb.select(self.music); self.music_status.set('이전 곡 설정을 불러왔습니다. 필요하면 수정 후 다시 생성하세요.')
 def on_close(self):
  try:
   import pygame
   if pygame.mixer.get_init():
    pygame.mixer.music.stop()
    pygame.mixer.quit()
  except Exception:pass
  self.player_proc=None
  p=getattr(self,'worker_proc',None)
  try:
   if p and p.poll() is None:
    p.terminate()
    try: p.wait(timeout=3)
    except: p.kill()
  except: pass
  self.destroy()
 def _advanced(self):
  self.vars={}; specs=[('Temperature','temperature','0.9'),('Top-P','top_p','0.93'),('Top-K','top_k','50'),('반복 억제','repetition_penalty','1.1'),('CFG Scale','cfg_scale','3.0'),('ODE Steps','ode_steps','32')]
  f=ttk.LabelFrame(self.advanced,text='YuE2 생성 파라미터',padding=14); f.pack(fill='x')
  for i,(lab,key,val) in enumerate(specs):
   ttk.Label(f,text=lab).grid(row=i,column=0,sticky='w',pady=5); v=tk.StringVar(value=val); self.vars[key]=v; ttk.Entry(f,textvariable=v,width=20).grid(row=i,column=1,sticky='w',padx=10)
  ttk.Label(self.advanced,text='일반 제작에서는 기본값을 그대로 사용해도 됩니다.',font=('Malgun Gothic',10)).pack(anchor='w',pady=12)
 def program_info(self):
  current='3.2.1'
  eng='정상' if (ENGINE/'py-runtime'/'venv'/'Scripts'/'python.exe').exists() else '확인 필요'
  model='정상' if MODELS.exists() else '확인 필요'
  messagebox.showinfo('프로그램 정보',
   f'jC-STUDIO DEV\n\n현재 버전: V{current} DEV\n개발 위치: {HOME}\n공용 YuE2 Engine: {eng}\nModels: {model}\n업데이트 채널: DEV\n\n'
   'DEV 업데이트는 개발판 App 코드만 교체합니다. STABLE 원본은 변경하지 않습니다.')

 def _update_version_tuple(self,v):
  try:return tuple(int(x) for x in re.findall(r'\d+',str(v))[:4])
  except Exception:return (0,)

 def check_update(self):
  current='3.2.1'
  manifest_url=os.environ.get('JC_STUDIO_DEV_UPDATE_MANIFEST','').strip()
  if not manifest_url:
   try:
    cfg=SETTINGS/'update-dev.json'
    if cfg.exists(): manifest_url=str(json.loads(cfg.read_text(encoding='utf-8')).get('manifest_url','')).strip()
   except Exception:pass
  if not manifest_url:
   messagebox.showinfo('DEV 최신 업데이트 확인',
    f'현재 버전: V{current} DEV\n업데이트 채널: DEV\n\nDEV 업데이트 서버 주소가 아직 등록되지 않았습니다.')
   return
  try:
   with urllib.request.urlopen(manifest_url,timeout=12) as r:
    meta=json.loads(r.read().decode('utf-8-sig'))
   latest=str(meta.get('version','0')); notes=str(meta.get('notes','')); url=str(meta.get('url','')); sha=str(meta.get('sha256','')).lower().strip()
   if self._update_version_tuple(latest)<=self._update_version_tuple(current):
    messagebox.showinfo('DEV 최신 업데이트 확인',f'DEV 최신 버전을 사용하고 있습니다.\n\n현재 버전: V{current} DEV'); return
   if not url: raise RuntimeError('DEV 업데이트 파일 URL이 없습니다.')
   if messagebox.askyesno('DEV 새 업데이트',f'DEV 새 버전 V{latest}을 사용할 수 있습니다.\n\n변경사항:\n{notes[:1200]}\n\nDEV에 설치하시겠습니까?'):
    self._install_dev_update(url,latest,sha)
  except Exception as e:messagebox.showerror('DEV 업데이트 확인 실패',str(e))

 def _install_dev_update(self,url,latest,sha256=''):
  try:
   tmp=Path(tempfile.mkdtemp(prefix='jcstudio_dev_update_'))
   pkg=tmp/'update.zip'
   urllib.request.urlretrieve(url,pkg)
   if sha256 and hashlib.sha256(pkg.read_bytes()).hexdigest().lower()!=sha256.lower().strip():
    raise RuntimeError('업데이트 파일 SHA-256 검증에 실패했습니다.')
   extract=tmp/'new'; extract.mkdir()
   with zipfile.ZipFile(pkg) as z:
    if 'jc_studio.py' not in z.namelist():
     raise RuntimeError('업데이트 ZIP에 jc_studio.py가 없습니다.')
    z.extractall(extract)
   newfile=extract/'jc_studio.py'
   py_compile.compile(str(newfile),doraise=True)

   appfile=Path(__file__).resolve()
   appdir=appfile.parent
   backup=tmp/'backup'; backup.mkdir()
   shutil.copy2(appfile,backup/'jc_studio.py')
   if (appdir/'Assets').exists():
    shutil.copytree(appdir/'Assets',backup/'Assets',dirs_exist_ok=True)

   helper=tmp/'jc_update_helper.py'
   helper.write_text("""import os,sys,time,shutil,subprocess
from pathlib import Path
pid=int(sys.argv[1]); appdir=Path(sys.argv[2]); newdir=Path(sys.argv[3]); backup=Path(sys.argv[4]); py=sys.argv[5]
for _ in range(120):
 try:
  os.kill(pid,0); time.sleep(.25)
 except OSError: break
try:
 shutil.copy2(newdir/'jc_studio.py',appdir/'jc_studio.py')
 if (newdir/'Assets').exists():
  shutil.copytree(newdir/'Assets',appdir/'Assets',dirs_exist_ok=True)
 p=subprocess.Popen([py,str(appdir/'jc_studio.py')],cwd=str(appdir),env=os.environ.copy())
 time.sleep(8)
 rc=p.poll()
 if rc is not None and rc!=0:
  shutil.copy2(backup/'jc_studio.py',appdir/'jc_studio.py')
  if (backup/'Assets').exists():
   shutil.copytree(backup/'Assets',appdir/'Assets',dirs_exist_ok=True)
  subprocess.Popen([py,str(appdir/'jc_studio.py')],cwd=str(appdir),env=os.environ.copy())
except Exception:
 try:
  shutil.copy2(backup/'jc_studio.py',appdir/'jc_studio.py')
  if (backup/'Assets').exists():
   shutil.copytree(backup/'Assets',appdir/'Assets',dirs_exist_ok=True)
  subprocess.Popen([py,str(appdir/'jc_studio.py')],cwd=str(appdir),env=os.environ.copy())
 except Exception: pass
""",encoding='utf-8')
   subprocess.Popen([sys.executable,str(helper),str(os.getpid()),str(appdir),str(extract),str(backup),sys.executable],
                    cwd=str(appdir),env=os.environ.copy(),
                    creationflags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0))
   messagebox.showinfo('업데이트 준비 완료',
    f'V{latest} 업데이트 파일 검증이 완료되었습니다.\n\n'
    '확인을 누르면 jC-STUDIO가 자동 종료되고 업데이트 후 다시 시작됩니다.\n'
    '새 버전 실행에 실패하면 이전 버전으로 자동 복구합니다.')
   self.after(150,self.destroy)
  except Exception as e:
   messagebox.showerror('업데이트 실패',str(e))


 def _system(self):
  stat=ttk.LabelFrame(self.system,text='PC / YuE2 상태',padding=10); stat.pack(fill='x')
  self.gpu=tk.StringVar(value='확인 중'); self.vram=tk.StringVar(value='확인 중'); self.driver=tk.StringVar(value='확인 중'); self.eng=tk.StringVar(value='확인 중'); self.mod=tk.StringVar(value='확인 중')
  for i,(a,v) in enumerate([('GPU',self.gpu),('VRAM',self.vram),('NVIDIA 드라이버',self.driver),('YuE2 엔진',self.eng),('모델',self.mod)]): ttk.Label(stat,text=a,width=18).grid(row=i,column=0,sticky='w',pady=2); ttk.Label(stat,textvariable=v).grid(row=i,column=1,sticky='w')
  btn=ttk.Frame(self.system); btn.pack(fill='x',pady=8)
  ttk.Button(btn,text='다시 진단',command=self.diagnose).pack(side='left',padx=3); ttk.Button(btn,text='V1.0 → 공용환경 이전',command=self.migrate_to_common_runtime).pack(side='left',padx=3); ttk.Button(btn,text='기존 YuE2 환경 복구',command=self.repair_moved_runtime).pack(side='left',padx=3); ttk.Button(btn,text='① 실행환경 확인/설치',command=self.install_python_runtime).pack(side='left',padx=3); ttk.Button(btn,text='② 모델 복구/이어받기',command=self.recover_models).pack(side='left',padx=3); ttk.Button(btn,text='③ 설치 검사',command=self.test_python_runtime).pack(side='left',padx=3); ttk.Button(btn,text='Runtime 폴더 열기',command=lambda: os.startfile(self.runtime_root()) if os.name=='nt' else None).pack(side='left',padx=3)
  pinfo=ttk.LabelFrame(self.system,text='프로그램 정보 / DEV 업데이트',padding=10); pinfo.pack(fill='x',pady=(4,8))
  ttk.Label(pinfo,text='현재 버전: V3.2.1 DEV · 채널: DEV').pack(side='left',padx=(0,14))
  ttk.Button(pinfo,text='프로그램 정보',command=self.program_info).pack(side='left',padx=4)
  ttk.Button(pinfo,text='DEV 최신 업데이트 확인',command=self.check_update,style='JC.Primary.TButton').pack(side='left',padx=4)
  ttk.Label(self.system,text='작업 로그').pack(anchor='w'); self.log=tk.Text(self.system,height=20,wrap='word',font=('Consolas',10),state='disabled'); self.log.pack(fill='both',expand=True,pady=4)
  self.sysprog=ttk.Progressbar(self.system,mode='determinate'); self.sysprog.pack(fill='x',pady=4)
 def write_log(self,s):
  stamp=time.strftime('%H:%M:%S'); line=f'[{stamp}] {s}\n';
  self.log.configure(state='normal'); self.log.insert('end',line); self.log.see('end'); self.log.configure(state='disabled')
  try:
   with (LOGS/'jC-STUDIO.log').open('a',encoding='utf-8') as f:f.write(line)
  except: pass
 def choose_out(self):
  p=filedialog.askdirectory(initialdir=self.outdir.get());
  if p:self.outdir.set(p)
 def runtime_root(self):
  try:
   if RUNTIME_CFG.exists():
    d=json.loads(RUNTIME_CFG.read_text(encoding='utf-8'))
    r=Path(d.get('runtime_root',''))
    if r.exists(): return r
  except Exception: pass
  return ENGINE/'py-runtime'
 def runtime_python(self):
  r=self.runtime_root(); p=r/'venv'/'Scripts'/'python.exe'
  return p if p.exists() else None
 def runtime_models(self):
  return self.runtime_root()/'models'
 def import_v09_runtime(self):
  from tkinter import filedialog, messagebox
  folder=filedialog.askdirectory(title='V0.9의 engine\\py-runtime 폴더를 선택하세요')
  if not folder: return
  r=Path(folder); py=r/'venv'/'Scripts'/'python.exe'; models=r/'models'
  if not py.exists() or not (models/'YuE2-3B'/'config.json').exists() or not (models/'YuE2-Vae'/'config.json').exists():
   messagebox.showerror('jC-STUDIO','선택한 폴더에서 정상적인 V0.9 YuE2 환경을 찾지 못했습니다.\nV0.9의 engine\\py-runtime 폴더를 선택해 주세요.'); return
  SETTINGS.mkdir(parents=True,exist_ok=True); RUNTIME_CFG.write_text(json.dumps({'runtime_root':str(r)},ensure_ascii=False,indent=2),encoding='utf-8')
  self.write_log('기존 V0.9 Runtime 연결: '+str(r)); self.diagnose(); self.test_python_runtime()
 def migrate_to_common_runtime(self):
  src=filedialog.askdirectory(title='현재 정상 동작하는 V1.0의 engine\\py-runtime 폴더를 선택하세요')
  if not src: return
  src=Path(src)
  sm=src/'models'
  if not (sm/'YuE2-3B'/'config.json').exists() or not (sm/'YuE2-Vae'/'config.json').exists():
   messagebox.showerror(APP,'선택한 폴더에서 YuE2-3B / YuE2-Vae 모델을 찾지 못했습니다.')
   return
  target=ENGINE/'py-runtime'
  try:
   if src.resolve()==target.resolve():
    messagebox.showinfo(APP,'이미 공용 Runtime을 사용하고 있습니다.')
    return
  except Exception: pass
  if not messagebox.askyesno(APP,'V1.0의 모델을 Documents\\jC-STUDIO 공용환경으로 복사하고, 공용 Python/YuE2 실행환경을 새로 구성합니다.\n\n원본 V1.0은 변경하거나 삭제하지 않습니다. 모델은 인터넷에서 다시 다운로드하지 않습니다.\n\n계속할까요?'):
   return
  def work():
   try:
    target.mkdir(parents=True,exist_ok=True)
    tm=target/'models'; tm.mkdir(parents=True,exist_ok=True)
    self.after(0,lambda:self.write_log('공용환경 이전 1/5: YuE2-3B 모델 복사 중...'))
    shutil.copytree(sm/'YuE2-3B',tm/'YuE2-3B',dirs_exist_ok=True)
    self.after(0,lambda:self.write_log('공용환경 이전 2/5: YuE2-Vae 모델 복사 중...'))
    shutil.copytree(sm/'YuE2-Vae',tm/'YuE2-Vae',dirs_exist_ok=True)
    if not (tm/'YuE2-3B'/'config.json').exists() or not (tm/'YuE2-Vae'/'config.json').exists(): raise RuntimeError('모델 복사 검증 실패')
    self.after(0,lambda:self.write_log('공용환경 이전 3/5: Python 3.12 공용 Runtime 구성 중...'))
    uv=target/'uv.exe'
    if not uv.exists():
     urllib.request.urlretrieve('https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip',target/'uv.zip')
     import zipfile
     with zipfile.ZipFile(target/'uv.zip') as z: z.extractall(target/'uvtmp')
     hits=list((target/'uvtmp').rglob('uv.exe'))
     if not hits: raise RuntimeError('uv.exe를 찾지 못했습니다')
     shutil.copy2(hits[0],uv)
    env=os.environ.copy(); env['UV_PYTHON_INSTALL_DIR']=str(target/'python'); env['UV_NO_PROGRESS']='1'
    # Never reuse a moved venv. Rebuild only executable environment in the stable common path.
    for d in (target/'venv',target/'python'):
     if d.exists(): shutil.rmtree(d,ignore_errors=True)
    subprocess.run([str(uv),'python','install','3.12'],env=env,check=True,cwd=target)
    pys=[x for x in (target/'python').rglob('python.exe') if 'Scripts' not in str(x)]
    if not pys: raise RuntimeError('Python 3.12 실행파일을 찾지 못했습니다')
    subprocess.run([str(uv),'venv','--python',str(pys[0]),str(target/'venv')],env=env,check=True,cwd=target)
    vp=target/'venv'/'Scripts'/'python.exe'
    self.after(0,lambda:self.write_log('공용환경 이전 4/5: PyTorch CUDA / YuE2 설치 중...'))
    subprocess.run([str(uv),'pip','install','--python',str(vp),'torch==2.10.0','--index-url','https://download.pytorch.org/whl/cu128'],env=env,check=True,cwd=target)
    subprocess.run([str(uv),'pip','install','--python',str(vp),'https://github.com/multimodal-art-projection/YuE/archive/refs/tags/yue2-v0.1.6.zip','imageio-ffmpeg==0.6.0','soundfile','huggingface_hub'],env=env,check=True,cwd=target)
    self.after(0,lambda:self.write_log('공용환경 이전 5/5: CUDA / YuE2 검증 중...'))
    code="import torch,yue2; print('CUDA',torch.cuda.is_available()); print('GPU',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NONE'); print('YuE2 OK')"
    r=subprocess.run([str(vp),'-c',code],capture_output=True,text=True,encoding='utf-8',errors='replace',env={**env,'HF_HOME':str(target/'hf')},timeout=180)
    self.after(0,lambda t=(r.stdout+r.stderr).strip():self.write_log(t))
    if r.returncode!=0 or 'YuE2 OK' not in r.stdout or 'CUDA True' not in r.stdout: raise RuntimeError('공용 Runtime 검증 실패')
    SETTINGS.mkdir(parents=True,exist_ok=True)
    RUNTIME_CFG.write_text(json.dumps({'runtime_root':str(target)},ensure_ascii=False,indent=2),encoding='utf-8')
    self.after(0,lambda:self.write_log('공용 Runtime 이전 완료: '+str(target)))
    self.after(0,self.diagnose)
    self.after(0,lambda:messagebox.showinfo(APP,'공용 Runtime 이전이 완료되었습니다.\n이제 jC-STUDIO는 V1.0 폴더를 참조하지 않습니다.\n\n음악 생성 테스트가 성공한 뒤 V1.0 보관 여부를 결정하세요.'))
   except Exception as e:
    self.after(0,lambda:self.write_log('공용환경 이전 오류: '+repr(e)))
    self.after(0,lambda:messagebox.showerror(APP,'이전 중 오류가 발생했습니다. V1.0 원본은 변경하지 않았습니다.\n\n'+str(e)))
  threading.Thread(target=work,daemon=True).start()
 def repair_moved_runtime(self):
  folder=filedialog.askdirectory(title='V1.0의 engine\\py-runtime 폴더를 선택하세요')
  if not folder: return
  rt=Path(folder)
  models=rt/'models'
  m3=(models/'YuE2-3B'/'config.json').exists()
  mv=(models/'YuE2-Vae'/'config.json').exists()
  if not (m3 and mv):
   messagebox.showerror(APP,'선택한 폴더에서 YuE2-3B / YuE2-Vae 모델을 찾지 못했습니다.\nV1.0의 engine\\py-runtime 폴더를 선택해 주세요.')
   return
  if not messagebox.askyesno(APP,'기존 모델은 그대로 보존하고, 이동으로 깨진 Python/venv만 현재 위치에서 다시 구성합니다.\n\n모델은 다시 다운로드하지 않습니다. PyTorch/YuE2 실행 패키지는 다시 설치됩니다.\n\n계속할까요?'):
   return
  SETTINGS.mkdir(parents=True,exist_ok=True)
  RUNTIME_CFG.write_text(json.dumps({'runtime_root':str(rt)},ensure_ascii=False,indent=2),encoding='utf-8')
  self.write_log('복구 대상 Runtime: '+str(rt))
  self.write_log('기존 모델 확인 완료: YuE2-3B / YuE2-Vae (보존)')
  def work():
   try:
    uv=rt/'uv.exe'
    if not uv.exists():
     self.after(0,lambda:self.write_log('1/6 uv 다운로드 중...'))
     import zipfile
     z=rt/'uv-repair.zip'
     urllib.request.urlretrieve('https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip',z)
     with zipfile.ZipFile(z) as f:f.extractall(rt)
     z.unlink(missing_ok=True)
    env=os.environ.copy(); env['UV_PYTHON_INSTALL_DIR']=str(rt/'python'); env['UV_NO_PROGRESS']='1'
    # Moved uv-managed Python and venv contain absolute paths. Rebuild only these; keep models/hf cache.
    self.after(0,lambda:self.write_log('2/6 이동으로 깨진 Python/venv 정리 중... (모델은 유지)'))
    for d in (rt/'venv', rt/'python'):
     if d.exists(): shutil.rmtree(d,ignore_errors=False)
    self.after(0,lambda:self.write_log('3/6 Python 3.12를 현재 경로에 다시 설치 중...'))
    subprocess.run([str(uv),'python','install','3.12'],env=env,check=True,cwd=rt)
    pys=[x for x in (rt/'python').rglob('python.exe') if 'Scripts' not in str(x)]
    if not pys: raise RuntimeError('복구용 Python 3.12 실행파일을 찾지 못했습니다.')
    py=pys[0]; venv=rt/'venv'
    subprocess.run([str(uv),'venv','--python',str(py),str(venv)],env=env,check=True,cwd=rt)
    vp=venv/'Scripts'/'python.exe'
    self.after(0,lambda:self.write_log('4/6 PyTorch CUDA 재설치 중...'))
    subprocess.run([str(uv),'pip','install','--python',str(vp),'torch==2.10.0','--index-url','https://download.pytorch.org/whl/cu128'],env=env,check=True,cwd=rt)
    self.after(0,lambda:self.write_log('5/6 YuE2 실행 패키지 재설치 중...'))
    subprocess.run([str(uv),'pip','install','--python',str(vp),'https://github.com/multimodal-art-projection/YuE/archive/refs/tags/yue2-v0.1.6.zip','imageio-ffmpeg==0.6.0','soundfile','huggingface_hub'],env=env,check=True,cwd=rt)
    self.after(0,lambda:self.write_log('6/6 Python/CUDA/YuE2 실행 검사 중...'))
    code="import torch,yue2; print('CUDA',torch.cuda.is_available()); print('GPU',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none'); print('YuE2 OK')"
    r=subprocess.run([str(vp),'-c',code],capture_output=True,text=True,encoding='utf-8',errors='replace',env={**env,'HF_HOME':str(rt/'hf')},timeout=180)
    txt=(r.stdout+'\n'+r.stderr).strip()
    self.after(0,lambda t=txt:self.write_log(t))
    if r.returncode!=0 or 'YuE2 OK' not in txt or 'CUDA True' not in txt:
     raise RuntimeError('실행 검사 실패: '+txt[-2000:])
    self.after(0,lambda:self.write_log('기존 환경 복구 완료. 모델 재다운로드 없이 사용할 수 있습니다.'))
    self.after(0,self.diagnose)
    self.after(0,lambda:messagebox.showinfo(APP,'복구 완료\n\n이제 30초 엔진 테스트로 음악 생성을 다시 시도해 주세요.'))
   except Exception as e:
    self.after(0,lambda err=repr(e):self.write_log('환경 복구 실패: '+err))
    self.after(0,lambda:messagebox.showerror(APP,'환경 복구 중 오류가 발생했습니다.\n\n작업 로그의 마지막 부분을 보내주세요.'))
  threading.Thread(target=work,daemon=True).start()

 def find_engine(self):
  return self.runtime_python()
 def install_python_runtime(self):
  if not messagebox.askyesno(APP,'YuE2 실행환경을 자동으로 설치합니다.\n\nPython 3.12, PyTorch CUDA, YuE2, 모델 약 8.4GB를 다운로드합니다.\n전체 다운로드 용량이 크므로 안정적인 인터넷 연결과 약 15GB 이상의 여유 공간이 필요합니다.\n\n계속할까요?'): return
  self.write_log('YuE2 자동 설치 시작')
  def work():
   try:
    rt=self.runtime_root(); rt.mkdir(parents=True,exist_ok=True)
    uv=rt/'uv.exe'
    if not uv.exists():
     self.after(0,lambda:self.write_log('1/5 uv 다운로드 중...'))
     import zipfile
     z=rt/'uv.zip'; urllib.request.urlretrieve('https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip',z)
     with zipfile.ZipFile(z) as f:f.extractall(rt)
     z.unlink(missing_ok=True)
    env=os.environ.copy(); env['UV_PYTHON_INSTALL_DIR']=str(rt/'python'); env['UV_NO_PROGRESS']='1'
    self.after(0,lambda:self.write_log('2/5 Python 3.12 준비 중...'))
    subprocess.run([str(uv),'python','install','3.12'],env=env,check=True,cwd=rt)
    # Locate managed python
    pys=list((rt/'python').rglob('python.exe'))
    if not pys: raise RuntimeError('Python 3.12 실행파일을 찾지 못했습니다.')
    py=pys[0]; venv=rt/'venv'
    self.after(0,lambda:self.write_log('3/5 전용 가상환경 생성 중...'))
    subprocess.run([str(uv),'venv','--python',str(py),str(venv)],env=env,check=True,cwd=rt)
    vp=venv/'Scripts'/'python.exe'
    self.after(0,lambda:self.write_log('4/5 PyTorch CUDA + YuE2 설치 중... (시간이 걸립니다)'))
    subprocess.run([str(uv),'pip','install','--python',str(vp),'torch==2.10.0','--index-url','https://download.pytorch.org/whl/cu128'],env=env,check=True,cwd=rt)
    subprocess.run([str(uv),'pip','install','--python',str(vp),'https://github.com/multimodal-art-projection/YuE/archive/refs/tags/yue2-v0.1.6.zip','imageio-ffmpeg==0.6.0','soundfile','huggingface_hub'],env=env,check=True,cwd=rt)
    self.after(0,lambda:self.write_log('1~4단계 실행환경 준비 완료'))
    self.after(0,lambda:self.write_log('이제 ② 모델 복구/이어받기를 눌러 모델을 준비해 주세요.'))
    self.after(0,self.diagnose)
   except Exception as e:
    self.after(0,lambda:self.write_log('자동 설치 실패: '+repr(e)))
    self.after(0,lambda:messagebox.showerror(APP,'YuE2 자동 설치 중 오류가 발생했습니다.\n\n시스템 로그의 마지막 내용을 보내주세요.'))
  threading.Thread(target=work,daemon=True).start()

 def recover_models(self):
  py=self.runtime_python()
  if not py:
   messagebox.showwarning(APP,'먼저 ① 실행환경 확인/설치를 실행해 주세요.'); return
  if not messagebox.askyesno(APP,'YuE2 모델 다운로드를 시작/이어받습니다.\n\n이미 받은 파일은 가능한 한 재사용합니다. 오류 원문도 로그에 표시합니다.\n\n계속할까요?'): return
  self.write_log('모델 복구/이어받기 시작')
  def work():
   rt=self.runtime_root(); models=self.runtime_models(); models.mkdir(parents=True,exist_ok=True)
   env={**os.environ,'HF_HOME':str(rt/'hf'),'HF_HUB_DOWNLOAD_TIMEOUT':'120'}
   code = "from huggingface_hub import snapshot_download; import sys; snapshot_download(sys.argv[1], local_dir=sys.argv[2], max_workers=4)"
   def one(repo,name,disable_xet=False):
    self.after(0,lambda:self.write_log(('Xet 비활성 복구: ' if disable_xet else '다운로드: ')+repo))
    e=env.copy()
    if disable_xet: e['HF_HUB_DISABLE_XET']='1'
    p=subprocess.Popen([str(py),'-c',code,repo,str(models/name)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',env=e,cwd=rt)
    for line in p.stdout:
     line=line.rstrip(); self.after(0,lambda x=line:self.write_log(x))
    return p.wait()
   try:
    for repo,name in [('m-a-p/YuE2-3B','YuE2-3B'),('m-a-p/YuE2-Vae','YuE2-Vae')]:
     rc=one(repo,name,False)
     if rc!=0:
      self.after(0,lambda r=repo:self.write_log(r+' 일반 다운로드 실패. Xet 비활성으로 재시도합니다.'))
      rc=one(repo,name,True)
     if rc!=0:
      raise RuntimeError(repo+' 다운로드 실패')
     self.after(0,lambda r=repo:self.write_log(r+' 다운로드 완료'))
    self.after(0,lambda:self.write_log('YuE2 모델 2종 준비 완료'))
    self.after(0,self.diagnose)
   except Exception as e:
    self.after(0,lambda:self.write_log('모델 복구 실패: '+repr(e)))
    self.after(0,lambda:messagebox.showerror(APP,'모델 다운로드 실패\n\n작업 로그에 실제 오류 원문을 표시했습니다. 마지막 오류 부분을 보내주세요.'))
  threading.Thread(target=work,daemon=True).start()
 def test_python_runtime(self):
  py=self.runtime_python()
  if not py: messagebox.showwarning(APP,'먼저 ① YuE2 자동 설치를 실행해 주세요.'); return
  self.write_log('YuE2 Runtime 검사 시작')
  def work():
   try:
    rt=self.runtime_root(); env={**os.environ,'HF_HOME':str(rt/'hf')}
    code="import torch,yue2; print('CUDA',torch.cuda.is_available()); print('GPU',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none'); print('YuE2 OK')"
    r=subprocess.run([str(py),'-c',code],capture_output=True,text=True,encoding='utf-8',errors='replace',env=env,timeout=120)
    txt=(r.stdout+'\n'+r.stderr).strip()
    self.after(0,lambda:self.write_log(txt))
    if r.returncode==0 and 'YuE2 OK' in txt: self.after(0,lambda:self.write_log('Runtime 검사 통과'))
    else: raise RuntimeError(txt[-2000:])
   except Exception as e:self.after(0,lambda:self.write_log('Runtime 검사 실패: '+repr(e)))
  threading.Thread(target=work,daemon=True).start()
 def diagnose(self):
  self.write_log('시스템 진단 시작')
  def work():
   gpu=vram=drv='감지되지 않음'
   try:
    exe=shutil.which('nvidia-smi') or str(Path(os.environ.get('ProgramFiles','C:/Program Files'))/'NVIDIA Corporation'/'NVSMI'/'nvidia-smi.exe')
    if Path(exe).exists() or shutil.which('nvidia-smi'):
     flags=getattr(subprocess,'CREATE_NO_WINDOW',0); p=subprocess.run([exe,'--query-gpu=name,memory.total,driver_version','--format=csv,noheader,nounits'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=15,creationflags=flags)
     if p.returncode==0 and p.stdout.strip():
      parts=[x.strip() for x in p.stdout.strip().splitlines()[0].split(',')]; gpu=parts[0]; vram=(parts[1]+' MB') if len(parts)>1 else '?'; drv=parts[2] if len(parts)>2 else '?'
   except Exception as e: self.after(0,lambda:self.write_log('GPU 진단 오류: '+str(e)))
   e=self.find_engine(); rt=self.runtime_root(); models=self.runtime_models(); modelok=(models/'YuE2-3B'/'config.json').exists() and (models/'YuE2-Vae'/'config.json').exists()
   def done():
    self.gpu.set(gpu); self.vram.set(vram); self.driver.set(drv); self.eng.set(str(e) if e else '설치/선택 필요'); self.mod.set('YuE2-3B + VAE 준비됨' if modelok else '다운로드/복구 필요')
    self.write_log(f'GPU: {gpu} / VRAM: {vram} / Driver: {drv}'); self.write_log('YuE2 엔진: '+(str(e) if e else '찾지 못함')); self.write_log('모델: '+('준비됨' if modelok else '필요'))
    self.make_btn.configure(state='normal')
    if not (e and modelok):
     self.music_status.set('YuE2 실행환경을 확인해 주세요. 음악 만들기를 누르면 필요한 항목을 안내합니다.')
   self.after(0,done)
  threading.Thread(target=work,daemon=True).start()
 def tool_path(self,name):
  return shutil.which(name)
 def runtime_candidates(self):
  """Known YuE2 Studio portable/install locations. No full-disk scan."""
  env=os.environ
  roots=[]
  for key in ('LOCALAPPDATA','PROGRAMFILES','PROGRAMFILES(X86)'):
   if env.get(key): roots.append(Path(env[key]))
  roots += [Path.home()/'Desktop', Path.home()/'Downloads', Path.home()/'Documents']
  candidates=[]
  direct=[
   Path(env.get('LOCALAPPDATA',''))/'YuE2 Studio'/'resources'/'yue2-cpp',
   Path(env.get('LOCALAPPDATA',''))/'Programs'/'YuE2 Studio'/'resources'/'yue2-cpp',
   Path(env.get('PROGRAMFILES','C:/Program Files'))/'YuE2 Studio'/'resources'/'yue2-cpp',
  ]
  for p in direct:
   if p and p.exists(): candidates.append(p)
  for root in roots:
   if not root.exists(): continue
   # Keep this shallow so the UI does not freeze on large user folders.
   patterns=['YuE2*Studio*','yue2*studio*']
   for pat in patterns:
    try:
     for base in root.glob(pat):
      if base.is_dir():
       candidates += [base/'resources'/'yue2-cpp', base/'resources', base]
    except Exception: pass
  # unique, existing only
  out=[]; seen=set()
  for p in candidates:
   try:k=str(p.resolve()).lower()
   except:k=str(p).lower()
   if k not in seen and p.exists(): seen.add(k); out.append(p)
  return out
 def copy_runtime_from(self, src):
  src=Path(src); hits=list(src.rglob('yue-server.exe'))
  if not hits: raise RuntimeError('yue-server.exe를 찾지 못했습니다.')
  server=hits[0]; source=server.parent; target=ENGINE/'runtime'; target.mkdir(parents=True,exist_ok=True)
  copied=[]
  for f in source.iterdir():
   if f.is_file() and (f.suffix.lower() in ('.exe','.dll') or f.name.lower().startswith(('license','notice'))):
    shutil.copy2(f,target/f.name); copied.append(f.name)
  if not (target/'yue-server.exe').exists(): raise RuntimeError('yue-server.exe 복사 실패')
  self.engine_path.set(str(target/'yue-server.exe'))
  return source,target,copied
 def auto_import_runtime(self):
  self.write_log('YuE2 Runtime 자동 검색 시작')
  def work():
   try:
    cands=self.runtime_candidates()
    self.after(0,lambda:self.write_log(f'후보 폴더 {len(cands)}개 확인'))
    found=None
    for p in cands:
     try:
      hits=list(p.rglob('yue-server.exe'))
      if hits: found=p; break
     except Exception: pass
    if not found:
     def nofound():
      self.write_log('자동 검색에서 YuE2 Studio Runtime을 찾지 못했습니다.')
      self.write_log('YuE2 Studio가 설치되어 있다면 수동 폴더 선택을 사용할 수 있습니다.')
      if messagebox.askyesno(APP,'YuE2 Studio Runtime을 자동으로 찾지 못했습니다.\n\n공식 YuE2 Studio 릴리스 페이지를 열까요?\n설치 후 다시 ① Runtime 자동 찾기를 누르면 됩니다.'):
       webbrowser.open('https://github.com/timoncool/YuE2-Studio/releases/latest')
     self.after(0,nofound); return
    source,target,copied=self.copy_runtime_from(found)
    self.after(0,lambda:self.write_log('Runtime 자동 가져오기 성공: '+str(source)))
    self.after(0,lambda:self.write_log(f'jC-STUDIO Runtime에 {len(copied)}개 파일 복사'))
    self.after(0,self.diagnose)
   except Exception as e:
    self.after(0,lambda:self.write_log('Runtime 자동 가져오기 오류: '+str(e)))
  threading.Thread(target=work,daemon=True).start()
 def import_runtime(self):
  messagebox.showinfo(APP,'YuE2 Studio 설치/포터블 폴더를 선택해 주세요.\n프로그램은 yue-server.exe와 필요한 DLL만 jC-STUDIO 전용 Runtime으로 복사하며 원본은 변경하지 않습니다.')
  src=filedialog.askdirectory(title='YuE2 Studio 또는 yue2.cpp Runtime 폴더 선택')
  if not src:return
  self.write_log('Runtime 검색: '+str(src))
  def work():
   try:
    source,target,copied=self.copy_runtime_from(src)
    self.after(0,lambda:self.write_log(f'Runtime 가져오기 완료: {len(copied)}개 파일'))
    self.after(0,lambda:self.write_log('원본 Runtime: '+str(source)))
    self.after(0,lambda:self.write_log('jC-STUDIO Runtime: '+str(target)))
    self.after(0,self.diagnose)
   except Exception as e:
    self.after(0,lambda:self.write_log('Runtime 가져오기 오류: '+str(e)))
    self.after(0,lambda:messagebox.showerror(APP,'Runtime 가져오기에 실패했습니다.\n\n'+str(e)))
  threading.Thread(target=work,daemon=True).start()
 def test_runtime(self):
  e=self.find_engine()
  if not e:
   messagebox.showwarning(APP,'YuE2 Runtime이 없습니다. 먼저 ① Runtime 가져오기를 실행해 주세요.'); return
  self.write_log('Runtime 실행 테스트: '+str(e))
  def work():
   try:
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    r=subprocess.run([str(e),'--help'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20,creationflags=flags,cwd=str(e.parent))
    text=(r.stdout+'\n'+r.stderr).strip()
    if r.returncode in (0,1) and text:
     self.after(0,lambda:self.write_log('Runtime 실행 성공. CUDA/DLL 로딩 기본 검사 통과.'))
     self.after(0,lambda:self.write_log(text[:1200]))
    else: raise RuntimeError(text or f'exit code {r.returncode}')
   except Exception as ex:
    self.after(0,lambda:self.write_log('Runtime 테스트 실패: '+str(ex)))
    self.after(0,lambda:messagebox.showerror(APP,'Runtime 테스트 실패\n\n시스템 로그를 확인해 주세요.'))
  threading.Thread(target=work,daemon=True).start()
 def check_build_tools(self):
  self.write_log('YuE2 Windows CUDA 빌드 도구 검사 시작')
  def work():
   checks=[]
   for label,cmd in [('Git','git'),('CMake','cmake'),('CUDA nvcc','nvcc')]:
    path=shutil.which(cmd); checks.append((label,path or '없음'))
   vswhere=Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Microsoft Visual Studio'/'Installer'/'vswhere.exe'
   msvc='없음'
   if vswhere.exists():
    try:
     r=subprocess.run([str(vswhere),'-latest','-products','*','-requires','Microsoft.VisualStudio.Component.VC.Tools.x86.x64','-property','installationPath'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=10)
     if r.stdout.strip(): msvc=r.stdout.strip()
    except: pass
   checks.append(('Visual C++ Build Tools',msvc))
   def done():
    for k,v in checks:self.write_log(f'{k}: {v}')
    missing=[k for k,v in checks if v=='없음']
    if missing:self.write_log('빌드 전 설치 필요: '+', '.join(missing))
    else:self.write_log('모든 빌드 도구 준비됨. ② YuE2 엔진 자동 빌드를 실행할 수 있습니다.')
   self.after(0,done)
  threading.Thread(target=work,daemon=True).start()
 def build_engine(self):
  if not messagebox.askyesno(APP,'공식 yue2.cpp 소스를 GitHub에서 받아 Windows CUDA 엔진을 빌드합니다.\n\nGit, CMake, Visual C++ Build Tools, CUDA Toolkit이 설치되어 있어야 합니다.\n계속할까요?'): return
  self.write_log('YuE2 CUDA 엔진 자동 빌드 시작')
  def work():
   try:
    needed=['git','cmake','nvcc']; missing=[x for x in needed if not shutil.which(x)]
    vswhere=Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Microsoft Visual Studio'/'Installer'/'vswhere.exe'
    if not vswhere.exists(): missing.append('Visual C++ Build Tools')
    if missing:
     self.after(0,lambda:self.write_log('자동 빌드 중단 - 없음: '+', '.join(missing))); return
    src=ENGINE/'yue2.cpp-src'
    if not src.exists():
     self.after(0,lambda:self.write_log('공식 yue2.cpp 소스 다운로드 중...'))
     r=subprocess.run(['git','clone','--recurse-submodules','https://github.com/ServeurpersoCom/yue2.cpp.git',str(src)],capture_output=True,text=True,encoding='utf-8',errors='replace')
     if r.returncode!=0: raise RuntimeError(r.stdout+'\n'+r.stderr)
    else:
     self.after(0,lambda:self.write_log('기존 yue2.cpp 소스 사용'))
     subprocess.run(['git','-C',str(src),'submodule','update','--init','--recursive'],capture_output=True)
    bld=src/'build-jc'; bld.mkdir(exist_ok=True)
    self.after(0,lambda:self.write_log('CMake CUDA 구성 중...'))
    r=subprocess.run(['cmake','-S',str(src),'-B',str(bld),'-DGGML_CUDA=ON'],capture_output=True,text=True,encoding='utf-8',errors='replace')
    if r.returncode!=0: raise RuntimeError(r.stdout+'\n'+r.stderr)
    self.after(0,lambda:self.write_log('Release 빌드 중... 시간이 걸릴 수 있습니다.'))
    r=subprocess.run(['cmake','--build',str(bld),'--config','Release','-j','4'],capture_output=True,text=True,encoding='utf-8',errors='replace')
    if r.returncode!=0: raise RuntimeError(r.stdout+'\n'+r.stderr)
    hits=list(bld.rglob('yue-synth.exe'))
    if not hits: raise RuntimeError('빌드는 끝났지만 yue-synth.exe를 찾지 못했습니다.')
    target=ENGINE/'runtime'; target.mkdir(exist_ok=True)
    for f in hits[0].parent.iterdir():
     if f.is_file() and f.suffix.lower() in ('.exe','.dll'): shutil.copy2(f,target/f.name)
    self.engine_path.set(str(target/'yue-synth.exe'))
    self.after(0,lambda:self.write_log('YuE2 CUDA 엔진 준비 완료: '+str(target/'yue-synth.exe')))
    self.after(0,self.diagnose)
   except Exception as e:
    msg=str(e)[-5000:]
    self.after(0,lambda:self.write_log('엔진 빌드 오류: '+msg))
    self.after(0,lambda:messagebox.showerror(APP,'YuE2 엔진 빌드에 실패했습니다.\n시스템 로그의 마지막 내용을 확인해 주세요.'))
  threading.Thread(target=work,daemon=True).start()
 def choose_engine(self):
  p=filedialog.askopenfilename(title='yue-server.exe 또는 yue-synth.exe 선택',filetypes=[('YuE2 실행파일','*.exe')]);
  if p:self.engine_path.set(p); self.write_log('엔진 선택: '+p); self.diagnose()
 def download_models(self):
  if not messagebox.askyesno(APP,'YuE2 Q8 모델(약 3.8GB)과 VAE(약 530MB)를 다운로드합니다.\n인터넷 연결과 약 5GB 이상의 여유 공간이 필요합니다. 계속할까요?'): return
  self.sysprog['value']=0; self.write_log('모델 다운로드 시작')
  def dl():
   try:
    total_files=len(MODEL_URLS)
    for idx,(name,url) in enumerate(MODEL_URLS.items()):
     dest=MODELS/name
     if dest.exists() and dest.stat().st_size>100_000_000: self.after(0,lambda n=name:self.write_log(n+' 이미 존재 - 건너뜀')); continue
     tmp=dest.with_suffix(dest.suffix+'.part')
     def hook(block,bs,total,idx=idx,name=name):
      if total>0:
       pct=((idx+(min(block*bs,total)/total))/total_files)*100; self.after(0,lambda p=pct:self.sysprog.configure(value=p))
     self.after(0,lambda n=name:self.write_log(n+' 다운로드 중...'))
     urllib.request.urlretrieve(url,tmp,hook); tmp.replace(dest); self.after(0,lambda n=name:self.write_log(n+' 완료'))
    self.after(0,lambda:self.sysprog.configure(value=100)); self.after(0,self.diagnose)
   except Exception as e:
    self.after(0,lambda:self.write_log('다운로드 오류: '+repr(e))); self.after(0,lambda:messagebox.showerror(APP,'모델 다운로드 중 오류가 발생했습니다.\n시스템 로그를 확인해 주세요.'))
  threading.Thread(target=dl,daemon=True).start()
 def voice_lock_text(self):
  presets={
   # Female
   '여성 · 일반 내추럴':'Single Korean adult female lead throughout, natural balanced mid register, neutral clear timbre, comfortable range, clear Korean diction, natural phrasing, consistent female vocal identity, no male lead, no gender switching',
   '여성 · 따뜻한 알토':'Single mature Korean female alto throughout, warm rich low-mid register, gentle chest resonance, clear Korean diction, natural controlled vibrato, sincere intimate delivery, no male lead, no soprano-led chorus, no belting, no gender switching',
   '여성 · 깊은 알토':'Single Korean female contralto/low alto throughout, deep resonant low-mid register, dark warm timbre, grounded chest voice, restrained natural vibrato, clear Korean diction, no male lead, no bright soprano shift, no belting',
   '여성 · 부드러운 메조':'Single Korean female mezzo-soprano throughout, smooth warm mid register, soft rounded tone, gentle expressive phrasing, clear Korean diction, controlled natural vibrato, no male lead, no piercing high notes, no belting',
   '여성 · 밝은 메조':'Single Korean female mezzo-soprano throughout, clear bright but soft timbre, balanced mid register, fresh natural tone, articulate Korean diction, restrained upper range, no male lead, no shrill soprano, no belting',
   '여성 · 맑은 소프라노':'Single Korean female soprano throughout, clear light natural tone, lyrical upper-mid register, soft controlled head-chest blend, clear Korean diction, gentle dynamics, no male lead, no operatic projection, no piercing highs',
   '여성 · 허스키':'Single Korean female lead throughout, warm husky textured timbre, smoky low-mid register, intimate close vocal, natural breath and restrained vibrato, clear Korean diction, no male lead, no harsh rasp, no belting',
   '여성 · 시니어 알토':'Single seasoned senior Korean female alto throughout, warm low-mid register, mature slightly weathered natural timbre, gentle chest voice, calm sincere delivery, clear Korean diction, controlled vibrato, no male lead, no soprano shift, no belting',
   # Male
   '남성 · 일반 내추럴':'Single Korean adult male lead throughout, natural balanced mid register, neutral clear timbre, comfortable range, clear Korean diction, natural phrasing, consistent male vocal identity, no female lead, no gender switching',
   '남성 · 따뜻한 바리톤':'Single mature Korean male baritone throughout, warm rich low-mid register, grounded chest resonance, clear Korean diction, natural controlled vibrato, sincere intimate delivery, no female lead, no tenor-led chorus, no falsetto, no belting',
   '남성 · 깊은 바리톤':'Single Korean male low baritone throughout, deep resonant low-mid register, dark warm timbre, full grounded chest voice, restrained natural vibrato, clear Korean diction, no female lead, no bright tenor shift, no falsetto',
   '남성 · 부드러운 테너':'Single Korean male tenor throughout, smooth gentle mid-to-upper-mid register, warm clear tone, relaxed phrasing, clear Korean diction, controlled head-chest blend, no female lead, no falsetto-led chorus, no belting',
   '남성 · 밝은 테너':'Single Korean male tenor throughout, bright clear youthful-adult timbre, focused mid register, articulate Korean diction, light natural vibrato, restrained upper range, no female lead, no feminine formant shift, no belting',
   '남성 · 허스키':'Single Korean male lead throughout, warm husky textured timbre, earthy low-mid register, intimate chest-dominant delivery, natural breath and restrained vibrato, clear Korean diction, no female lead, no harsh growl, no belting',
   '남성 · 시니어 바리톤':'Single seasoned senior Korean male baritone throughout, warm deep low-mid register, mature slightly weathered natural timbre, grounded gentle chest voice, calm sincere delivery, clear Korean diction, controlled vibrato, no female lead, no tenor shift, no falsetto, no belting',
   # Duets
   '듀엣 · 남성 바리톤 + 여성 알토':'Same Korean male baritone and female alto duet pair throughout, warm low-mid registers, alternate verse lines or sections intentionally, sing choruses together with restrained close harmony, clear Korean diction, consistent duet roles and vocal identities, no extra lead singer, no choir, no gender-role switching',
   '듀엣 · 남성 테너 + 여성 메조':'Same Korean male tenor and female mezzo-soprano duet pair throughout, smooth complementary mid registers, intentional alternating sections, gentle blended chorus harmony, clear Korean diction, consistent duet roles and vocal identities, no extra lead singer, no choir',
   '듀엣 · 시니어 남녀':'Same seasoned senior Korean male baritone and senior female alto duet pair throughout, warm mature slightly weathered timbres, calm low-mid registers, conversational alternating verses, soft shared choruses, clear Korean diction, consistent duet roles, no extra choir, no youthful vocal shift',
   '듀엣 · 남성 2인':'Same two Korean male singers throughout: warm baritone lead plus gentle tenor support, clearly assigned parts, restrained two-part harmony in choruses, consistent masculine vocal identities, clear Korean diction, no female lead, no choir, no singer replacement',
   '듀엣 · 여성 2인':'Same two Korean female singers throughout: warm alto lead plus gentle mezzo support, clearly assigned parts, restrained two-part harmony in choruses, consistent female vocal identities, clear Korean diction, no male lead, no choir, no singer replacement',
   '듀엣 · 저음 남녀':'Same low-register Korean duet pair throughout: mature male baritone and mature female alto, clearly alternating assigned sections with restrained low harmony, warm low-mid registers, clear Korean diction, consistent duet roles, no soprano, no high tenor, no falsetto, no belting, no extra choir',
   # Backward compatibility for saved projects
   '따뜻한 중후 여성 알토':'Single mature Korean female alto throughout, warm rich low-mid register, gentle chest resonance, clear Korean diction, natural controlled vibrato, sincere intimate delivery, no male lead, no soprano-led chorus, no belting, no gender switching',
   '따뜻한 중후 남성 바리톤':'Single mature Korean male baritone throughout, warm rich low-mid register, grounded chest resonance, clear Korean diction, natural controlled vibrato, sincere intimate delivery, no female lead, no tenor-led chorus, no falsetto, no belting',
   '저음 여성·남성 듀엣':'Same low-register Korean duet pair throughout: mature male baritone and mature female alto, clearly alternating assigned sections with restrained low harmony, warm low-mid registers, clear Korean diction, consistent duet roles, no soprano, no high tenor, no falsetto, no belting, no extra choir',
   '악기 연주':'instrumental only, no vocal, no spoken voice, no choir'
  }
  return presets.get(self.voice.get(), presets['여성 · 따뜻한 알토'])
 def automatic_style(self):
  parts=[self.voice_lock_text(), self.vocal_enrichment_prompt(), f'{self.bpm.get()} BPM', self.key.get(), GENRE_PRESETS.get(self.genre.get(),''), self.selected_instrument_text(), f'target length {self.length.get()}']
  if self.auto_exclude.get(): parts.append(EXCLUDE_DEFAULT)
  return ', '.join(x.strip(' ,') for x in parts if x and x.strip())
 def set_style_text(self,text,readonly=False):
  self.style.configure(state='normal'); self.style.delete('1.0','end'); self.style.insert('1.0',text)
  self.style.configure(state='disabled' if readonly else 'normal')
 def on_prompt_mode_change(self):
  mode=self.prompt_mode.get()
  if mode=='자동 생성': self.set_style_text(self.automatic_style(),True)
  elif mode=='자동 생성 후 편집': self.set_style_text(self.automatic_style(),False)
  else:
   self.style.configure(state='normal')
   if self.style.get('1.0','end').strip()==self.automatic_style().strip(): self.set_style_text('',False)
 def recommended_instrument_text(self):
  g=self.genre.get()
  if g in ('재즈 CCM','재즈 발라드 CCM'):
   return 'warm grand piano, upright bass, soft brushed drums, mellow tenor saxophone, subtle jazz guitar'
  if g=='스윙 워십':
   return 'jazz piano, upright bass, light brushed swing drums, clean jazz guitar, restrained clarinet'
  if g in ('감성 트로트 CCM','어쿠스틱 트로트 CCM','세미 트로트 CCM'):
   return 'acoustic guitar, warm piano, soft drum kit, warm electric bass, restrained accordion, subtle strings'
  if g in ('모던 워십','컨템포러리 CCM','CCM Pop','Soft Pop Worship'):
   return 'warm piano, clean electric guitar, soft electric bass, restrained drum kit, subtle ambient strings'
  if g=='Acoustic CCM Pop':
   return 'fingerpicked acoustic guitar, warm piano, soft electric bass, shaker, light brushed drums'
  if g in ('찬송가풍','Gospel Hymn'):
   return 'grand piano, restrained church organ, warm upright bass, soft strings, very light brushed percussion'
  if g=='오르간 워십':
   return 'church organ, grand piano, restrained strings, soft cello'
  if g in ('Acoustic Cinematic CCM','Cinematic Worship'):
   return 'felt piano, fingerpicked acoustic guitar, solo cello, viola, restrained string ensemble, soft brushed percussion'
  if g in ('포크 워십','어쿠스틱 포크 CCM'):
   return 'fingerpicked acoustic guitar, mandolin, upright bass, soft brushed drums, gentle harmonica'
  if g=='시니어 CCM':
   return 'fingerpicked acoustic guitar, warm felt piano, upright bass, soft brushed drums, solo cello'
  if g=='CCM 발라드':
   return 'warm piano, fingerpicked acoustic guitar, solo cello, upright bass, soft brushed drums'
  return 'fingerpicked acoustic guitar, warm felt piano, upright bass, soft brushed drums, restrained cello'

 def selected_instrument_text(self):
  v=INSTRUMENT_PRESETS.get(self.instrument.get(),'AUTO')
  return self.recommended_instrument_text() if v=='AUTO' else v

 def _richness_changed(self):
  try:
   n=max(1,min(5,int(round(float(self.vocal_richness.get())))))
   labels={1:'1 · 담백',2:'2 · 자연',3:'3 · 풍성',4:'4 · 매우 풍성',5:'5 · 깊고 풍성'}
   if hasattr(self,'vocal_richness_label'): self.vocal_richness_label.set(labels[n])
   self.refresh_final_prompt()
  except Exception: pass

 def vocal_enrichment_prompt(self):
  tone=VOCAL_TONE_PRESETS.get(self.vocal_tone.get(),VOCAL_TONE_PRESETS['기본 · 자연스러움'])
  try: n=max(1,min(5,int(round(float(self.vocal_richness.get())))))
  except Exception: n=2
  richness=VOCAL_RICHNESS[n]
  mix='vocal-forward organic mix, instruments gently behind the lead vocal, warm low-mid presence, controlled natural reverb, soft transients, no excessive brightness, no harsh compression'
  return tone+', '+richness+', '+mix

 def refresh_final_prompt(self):
  if not hasattr(self,'style'): return
  if self.prompt_mode.get()=='자동 생성': self.set_style_text(self.automatic_style(),True)
 def apply_manual_prompt_additions(self):
  if self.prompt_mode.get()=='자동 생성': return
  base=self.style.get('1.0','end').strip(); add=[]
  if self.manual_voice_lock.get(): add.append(self.voice_lock_text())
  if self.manual_exclude.get(): add.append(EXCLUDE_DEFAULT)
  if add:
   self.set_style_text(', '.join([x for x in [base]+add if x]),False)
   self.manual_voice_lock.set(False); self.manual_exclude.set(False)
 def composed_style(self):
  return self.style.get('1.0','end').strip()
 def repeat_generation(self):
  # Same visible settings; a fixed Seed reproduces more closely, Random creates a variation.
  self.generate()
 def save_song_metadata(self, folder, req):
  meta={'title':self.titlev.get(),'created_at':datetime.now().isoformat(timespec='seconds'),'genre':self.genre.get(),'instrument_preset':self.instrument.get(),'voice':self.voice.get(),'bpm':self.bpm.get(),'key':self.key.get(),'target_length':self.length.get(),'seed':req.get('seed'),'style':req.get('style'),'lyrics':req.get('lyrics'),'advanced':req.get('advanced')}
  (folder/'song-info.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
  (folder/'lyrics.txt').write_text(req.get('lyrics',''),encoding='utf-8')
  (folder/'style.txt').write_text(req.get('style',''),encoding='utf-8')
 def make_mp3(self,audio):
  try:
   py=self.runtime_python(); rt=self.runtime_root()
   if not py or not audio or not Path(audio).exists(): return None
   out=Path(audio).with_suffix('.mp3')
   code="import imageio_ffmpeg,subprocess,sys; ff=imageio_ffmpeg.get_ffmpeg_exe(); subprocess.run([ff,'-y','-i',sys.argv[1],'-codec:a','libmp3lame','-q:a','2',sys.argv[2]],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)"
   kw={}
   if os.name=='nt': kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
   r=subprocess.run([str(py),'-c',code,str(audio),str(out)],cwd=rt,**kw)
   return str(out) if r.returncode==0 and out.exists() else None
  except Exception as e:
   self.after(0,lambda:self.write_log('MP3 저장 오류: '+repr(e))); return None

 def payload(self):
  seed=None if self.seed.get().strip() in ('','랜덤','random') else int(self.seed.get())
  length=self.length.get()
  style=self.composed_style()
  # YuE2 token caps are approximate duration controls. 30-second mode is intentionally conservative for first CUDA validation.
  caps={'30초 엔진 테스트':(650,500),'약 1분':(1350,900),'약 2분':(2600,1800),'2분 40초':(3500,2600),'약 3분':(4000,3000),'약 3분 30초':(4700,3500),'약 4분':(5400,4000),'약 4분 30초':(6100,4600),'약 5분':(6800,5200),'약 5분 30초':(7500,5800),'약 6분':(8200,6300)}
  max_tokens,min_tokens=caps.get(length,(5000,0))
  adv={
   'temperature':float(self.vars['temperature'].get()),
   'topP':float(self.vars['top_p'].get()),
   'topK':int(float(self.vars['top_k'].get())),
   'repetitionPenalty':float(self.vars['repetition_penalty'].get()),
   'cfgScale':float(self.vars['cfg_scale'].get()),
   'odeSteps':int(float(self.vars['ode_steps'].get())),
   'maxTokens':max_tokens,
   'minTokens':min_tokens,
  }
  return {'style':style,'lyrics':self.lyrics.get('1.0','end').strip(),'seed':seed,'advanced':adv,'instrumental':self.voice.get()=='악기 연주'}
 def _set_generation_progress(self, percent, stage=None):
  percent=max(0,min(100,float(percent)))
  self.gen_percent.set(percent); self.gen_percent_text.set(f'{int(round(percent))}%')
  if stage: self.gen_stage.set('현재 단계: '+stage)
  if self.gen_started:
   elapsed=max(0,time.time()-self.gen_started); self.gen_time.set(f'경과 {int(elapsed//60):02d}:{int(elapsed%60):02d}')
   if percent>=3 and percent<100:
    total=elapsed/(percent/100.0); remain=max(0,total-elapsed); self.gen_eta.set(f'예상 남은 시간 약 {int(remain//60):02d}:{int(remain%60):02d}')
   elif percent>=100: self.gen_eta.set('완료')

 def _progress_from_event(self, ev):
  typ=ev.get('type'); stage=ev.get('stage')
  names={'load':'모델 준비','plan':'곡 구성·악보 생성','semantic':'보컬·음악 구성 생성','synth':'음원 생성','decode':'오디오 변환','save':'파일 저장'}
  if typ=='stage':
   status=ev.get('status','')
   bases={'load':3,'plan':10,'semantic':35,'synth':60,'decode':95,'save':98}
   ends={'load':10,'plan':35,'semantic':60,'synth':95,'decode':98,'save':99}
   pct=ends.get(stage,bases.get(stage,1)) if status=='done' else bases.get(stage,1)
   return pct,names.get(stage,stage or '처리 중')
  if typ=='progress':
   if stage=='plan': return 10+25*min(float(ev.get('tokens',0))/1000.0,0.99),names['plan']
   if stage=='semantic': return 35+25*min(float(ev.get('tokens',0))/700.0,0.99),names['semantic']
   if stage=='synth':
    steps=max(1,float(ev.get('steps',32))); return 60+35*min(float(ev.get('step',0))/steps,1.0),names['synth']
  if typ=='done': return 100,'완료'
  return None,None

 def play_result(self):
  try:
   if getattr(self,'last_audio',None) and Path(self.last_audio).exists():
    self.nb.select(self.library); self.player_title.set(Path(self.last_audio).name); self._start_internal_player(self.last_audio)
   else: messagebox.showinfo(APP,'재생할 완성곡이 없습니다.')
  except Exception as e: messagebox.showerror(APP,'재생할 수 없습니다: '+str(e))

 def open_result_folder(self):
  try:
   if self.gen_folder and Path(self.gen_folder).exists(): os.startfile(self.gen_folder)
  except Exception as e: messagebox.showerror(APP,'폴더를 열 수 없습니다: '+str(e))

 def generate(self):
  py=self.runtime_python(); rt=self.runtime_root(); models=self.runtime_models()
  m3=models/'YuE2-3B'; mv=models/'YuE2-Vae'
  if not py or not (m3/'config.json').exists() or not (mv/'config.json').exists():
   messagebox.showwarning(APP,'YuE2 실행환경과 모델 준비가 먼저 필요합니다.'); self.nb.select(self.system); return
  try:req_base=self.payload(); count=max(1,min(3,int(self.song_count.get())))
  except Exception as e: messagebox.showerror(APP,'설정값 오류: '+str(e)); return
  if not req_base['lyrics']:
   messagebox.showwarning(APP,'가사를 입력해 주세요.'); return
  root_folder=Path(self.outdir.get())/(self.titlev.get().strip() or 'song')/time.strftime('%Y%m%d-%H%M%S'); root_folder.mkdir(parents=True,exist_ok=True)
  self.make_btn.configure(state='disabled'); self.play_btn.configure(state='disabled'); self.folder_btn.configure(state='disabled'); self.repeat_btn.configure(state='disabled')
  self.music_status.set(f'{count}곡을 순서대로 만들고 있습니다...'); self.gen_started=time.time(); self.gen_folder=root_folder; self.last_audio=None; self._set_generation_progress(1,f'1/{count}곡 준비 중'); self.write_log(f'음악 생성 시작: {count}곡 / '+str(root_folder))
  def run():
   p=None; completed=0; last_audio=None
   try:
    for idx in range(1,count+1):
     folder=root_folder/(f'version_{idx:02d}' if count>1 else '')
     folder.mkdir(parents=True,exist_ok=True)
     req=dict(req_base); req['advanced']=dict(req_base['advanced'])
     # 랜덤 모드는 각 버전마다 다른 seed. 고정 seed는 2곡 이상에서도 변형을 위해 순차 seed 사용.
     if req_base.get('seed') is None: req['seed']=random.randrange(2**31)
     elif count>1: req['seed']=(int(req_base['seed']) + idx - 1) % (2**31)
     (folder/'request.json').write_text(json.dumps(req,ensure_ascii=False,indent=2),encoding='utf-8'); self.save_song_metadata(folder,req)
     self.after(0,lambda i=idx:self.music_status.set(f'{i}/{count}곡 생성 중...'))
     self.after(0,lambda i=idx:self.gen_stage.set(f'현재 단계: {i}/{count}곡 준비 중'))
     self.after(0,lambda i=idx:self.write_log(f'[{i}/{count}] 생성 시작 · Seed {req.get("seed")} · {folder}'))
     env={**os.environ,'HF_HOME':str(rt/'hf'),'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','JC_YUE2_3B':str(m3),'JC_YUE2_VAE':str(mv),'JC_MEMORY_GIB':'8'}
     worker=BASE/'yue_worker.py'; popen_kw={}
     if os.name=='nt':
      popen_kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0); si=subprocess.STARTUPINFO(); si.dwFlags |= subprocess.STARTF_USESHOWWINDOW; si.wShowWindow=0; popen_kw['startupinfo']=si
     p=subprocess.Popen([str(py),'-u',str(worker)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',env=env,cwd=BASE,**popen_kw)
     self.worker_proc=p; sent=False; jobid=f'jc-{idx}-'+time.strftime('%H%M%S'); failed=False
     for line in p.stdout:
      line=line.strip()
      if not line: continue
      try:
       ev=json.loads(line); typ=ev.get('type')
       if typ=='ready': msg=f'[{idx}/{count}] YuE2 worker 준비 완료 / GPU: '+str(ev.get('gpu'))
       elif typ=='stage': msg=f"[{idx}/{count}] 단계 {ev.get('stage')}: {ev.get('status','')}"
       elif typ=='progress': msg=None
       elif typ=='notice': msg=ev.get('message','알림')
       elif typ=='done': msg=f'[{idx}/{count}] 음악 생성 완료: '+str(ev.get('audio'))
       elif typ=='error': msg=f'[{idx}/{count}] 생성 오류: '+ev.get('message','')
       else: msg=json.dumps(ev,ensure_ascii=False)
       pct,stage_name=self._progress_from_event(ev)
       if pct is not None:
        overall=((idx-1)*100+pct)/count
        label=f'{idx}/{count}곡 · {stage_name}' if count>1 else stage_name
        self.after(0,lambda p=overall,n=label:self._set_generation_progress(p,n))
       if msg: self.after(0,lambda x=msg:self.write_log(x))
       if typ=='ready' and not sent:
        cmd={'cmd':'generate','jobId':jobid,'outDir':str(folder),'style':req['style'],'lyrics':req['lyrics'],'seed':req.get('seed'),'cot':'full','id':f"jc_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{idx}_{uuid.uuid4().hex[:6]}",'advanced':req['advanced'],'instrumental':req['instrumental']}
        p.stdin.write(json.dumps(cmd,ensure_ascii=False)+'\n'); p.stdin.flush(); sent=True
       if typ=='done':
        audio=ev.get('audio'); last_audio=audio
        try:
         info=folder/'song-info.json'
         meta=json.loads(info.read_text(encoding='utf-8')) if info.exists() else {}
         meta['audio_path']=str(Path(audio).resolve()) if audio else ''
         meta['created_at']=datetime.now().strftime('%Y%m%d-%H%M%S')
         info.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
        except Exception as e:self.after(0,lambda x=e:self.write_log('오디오 경로 기록 오류: '+str(x)))
        mp3=self.make_mp3(audio)
        if mp3: self.after(0,lambda m=mp3,i=idx:self.write_log(f'[{i}/{count}] MP3 동시 저장 완료: '+m))
        completed+=1; break
       if typ=='error':
        detail=ev.get('detail')
        if detail:self.after(0,lambda d=detail:self.write_log(d[-4000:]))
        failed=True; break
      except json.JSONDecodeError: self.after(0,lambda x=line:self.write_log(x))
     try:
      if p and p.poll() is None:
       p.terminate()
       try:p.wait(timeout=3)
       except:p.kill()
     except: pass
     self.worker_proc=None; p=None
     if failed: break
    self.last_audio=last_audio
    if completed==count:
     self.after(0,lambda:self._set_generation_progress(100,'완료'))
     self.after(0,lambda:self.music_status.set(f'{count}곡 생성 완료 · 각 버전에 WAV/MP3 저장'))
     self.after(0,lambda:self.play_btn.configure(state='normal' if last_audio else 'disabled')); self.after(0,lambda:self.folder_btn.configure(state='normal')); self.after(0,lambda:self.repeat_btn.configure(state='normal'))
    else:
     self.after(0,lambda:self.music_status.set(f'{completed}/{count}곡 완료 · 생성 중 오류 발생')); self.after(0,lambda:self.gen_stage.set('현재 단계: 오류 발생'))
   except Exception as e:
    self.after(0,lambda:self.write_log('생성 실행 오류: '+repr(e))); self.after(0,lambda:self.music_status.set('생성 실패')); self.after(0,lambda:self.gen_stage.set('현재 단계: 오류 발생'))
   finally:
    try:
     if p and p.poll() is None:
      p.terminate()
      try:p.wait(timeout=3)
      except:p.kill()
    except: pass
    self.worker_proc=None; self.after(0,lambda:self.make_btn.configure(state='normal')); self.after(0,self.refresh_library)
  threading.Thread(target=run,daemon=True).start()

if __name__=='__main__': App().mainloop()
