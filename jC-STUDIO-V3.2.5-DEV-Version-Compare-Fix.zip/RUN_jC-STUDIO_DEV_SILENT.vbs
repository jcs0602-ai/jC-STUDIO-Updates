﻿Set sh = CreateObject("WScript.Shell")
sh.Environment("PROCESS")("JC_STUDIO_HOME") = "D:\jC-STUDIO-DEV"
sh.Environment("PROCESS")("JC_STUDIO_ENGINE_HOME") = "D:\jC-STUDIO\Engine"
sh.Environment("PROCESS")("JC_STUDIO_MODELS_HOME") = "D:\jC-STUDIO\Engine\py-runtime\models"
sh.Run """D:\jC-STUDIO\Engine\py-runtime\venv\Scripts\pythonw.exe"" ""D:\jC-STUDIO-DEV\App\jc_studio.py""", 0, False
